//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by nuvotonmagicboardutil.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NUVOTON_MAGIC_BOARD_UTIL_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     133
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON4                     1068
#define IDC_BUTTON5                     1069
#define IDC_BUTTON6                     1070
#define IDC_BUTTON7                     1071
#define IDC_STATICBOOT                  1072
#define IDC_BUTTON8                     1073
#define IDC_STATICVERSION               1074
#define IDC_STATICISP                   1075
#define IDC_BUTTON9                     1076
#define IDC_BUTTON10                    1077
#define IDC_BUTTON11                    1078
#define IDC_BUTTON12                    1079
#define IDC_BUTTON13                    1080
#define IDC_BUTTON14                    1081
#define IDC_BUTTON15                    1082
#define IDC_BUTTON16                    1083
#define IDC_BUTTON17                    1084
#define IDC_STATIC7                     1086
#define IDC_STATIC8                     1087
#define IDC_STATIC4                     1088
#define IDC_STATIC10                    1089
#define IDC_STATIC3                     1090
#define IDC_TB1                         1201
#define IDC_TB2                         1202
#define IDC_TB3                         1203
#define IDC_TB4                         1204
#define IDC_TB5                         1205
#define IDC_TB6                         1206
#define IDC_TB7                         1207
#define IDC_TB8                         1208
#define IDC_TB9                         1209
#define IDC_TB10                        1210
#define IDC_TB11                        1211
#define IDC_TB12                        1212
#define IDC_TB13                        1213
#define IDC_TB14                        1214
#define IDC_TB15                        1215
#define IDC_TB16                        1216
#define IDC_TB17                        1217
#define IDC_TB18                        1218
#define IDC_TB19                        1219
#define IDC_TB20                        1220
#define IDC_TB21                        1221
#define IDC_TB22                        1222
#define IDC_TB23                        1223
#define IDC_TB24                        1224
#define IDC_TB25                        1225
#define IDC_TB26                        1226
#define IDC_TB27                        1227
#define IDC_TB28                        1228
#define IDC_TB29                        1229
#define IDC_TB30                        1230
#define IDC_TB31                        1231
#define IDC_TB32                        1232
#define IDC_TB33                        1233
#define IDC_TB34                        1234
#define IDC_TB35                        1235
#define IDC_TB36                        1236
#define IDC_TB37                        1237
#define IDC_TB38                        1238
#define IDC_TB39                        1239
#define IDC_TB40                        1240
#define IDC_TB41                        1241
#define IDC_TB42                        1242
#define IDC_TB43                        1243
#define IDC_TB44                        1244
#define IDC_TB45                        1245
#define IDC_TB46                        1246
#define IDC_TB47                        1247
#define IDC_TB48                        1248
#define IDC_TB49                        1249
#define IDC_TB50                        1250
#define IDC_TB51                        1251
#define IDC_TB52                        1252
#define IDC_TB53                        1253
#define IDC_TB54                        1254
#define IDC_TB55                        1255
#define IDC_TB56                        1256
#define IDC_TB57                        1257
#define IDC_TB58                        1258
#define IDC_TB59                        1259
#define IDC_TB60                        1260
#define IDC_TB61                        1261
#define IDC_TB62                        1262
#define IDC_TB63                        1263
#define IDC_TB64                        1264

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1091
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
