﻿
// nuvoton_magic_board_utilDlg.cpp : implementation file
//

#define  _CRT_SECURE_NO_WARNINGS
#include "framework.h"
#include "nuvoton_magic_board_util.h"
#include "nuvoton_magic_board_utilDlg.h"
#include "afxdialogex.h"
#include <io.h>  
#include <fcntl.h>
#include "stdint.h"
#include "ISP_COMMAND.h"
#include "caboutbox.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CnuvotonmagicboardutilDlg dialog

BOOL image_array[64] = { FALSE };
void Button_OFF(CMFCButton& button) {
	button.SetFaceColor(RGB(255, 255, 255), true);
	button.m_bTransparent = FALSE;
	button.m_bDontUseWinXPTheme = TRUE;
	button.m_bDrawFocus = FALSE;
}
void Button_ON(CMFCButton& button) {
	button.SetFaceColor(RGB(0, 0, 0), true);
	button.m_bTransparent = FALSE;
	button.m_bDontUseWinXPTheme = TRUE;
	button.m_bDrawFocus = FALSE;
}
CnuvotonmagicboardutilDlg::CnuvotonmagicboardutilDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_NUVOTON_MAGIC_BOARD_UTIL_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CnuvotonmagicboardutilDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);

	for (int i = 0; i < 64; ++i) {
		UINT nID = IDC_TB1 + i; // 计算按钮的标识符
		DDX_Control(pDX, nID, TB[i]); // 使用 DDX_Control 宏声明控件
	}
	DDX_Control(pDX, IDC_STATIC4,  m_staSF);
	DDX_Control(pDX, IDC_STATIC10,  m_staIF);
	DDX_Control(pDX, IDC_STATIC3,  m_staFF);


	//DDX_Control(pDX, IDC_TB1, TB[0]);

}

BEGIN_MESSAGE_MAP(CnuvotonmagicboardutilDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_CLOSE()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CnuvotonmagicboardutilDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &CnuvotonmagicboardutilDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON5, &CnuvotonmagicboardutilDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON8, &CnuvotonmagicboardutilDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON4, &CnuvotonmagicboardutilDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON7, &CnuvotonmagicboardutilDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON2, &CnuvotonmagicboardutilDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON6, &CnuvotonmagicboardutilDlg::OnBnClickedButton6)
	
	ON_BN_CLICKED(IDC_BUTTON9, &CnuvotonmagicboardutilDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &CnuvotonmagicboardutilDlg::OnBnClickedButton10)
	ON_BN_CLICKED(IDC_BUTTON11, &CnuvotonmagicboardutilDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON12, &CnuvotonmagicboardutilDlg::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &CnuvotonmagicboardutilDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON14, &CnuvotonmagicboardutilDlg::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &CnuvotonmagicboardutilDlg::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_BUTTON16, &CnuvotonmagicboardutilDlg::OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON17, &CnuvotonmagicboardutilDlg::OnBnClickedButton17)
	ON_COMMAND_RANGE(IDC_TB1,IDC_TB64, TBOnButtonClick)
END_MESSAGE_MAP()


// CnuvotonmagicboardutilDlg message handlers

void InitializeMyButton(CMFCButton& button) {
	button.SetFaceColor(RGB(255, 255, 255), true);
	button.m_bTransparent = FALSE;
	button.m_bDontUseWinXPTheme = TRUE;
	button.m_bDrawFocus = FALSE;
}

BOOL CnuvotonmagicboardutilDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();


	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon	
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	this->SetWindowText(_T("NUVOTON MAGIC BOARD UTIL V1.0"));
#if relase_mode
	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("Magic Board USB Devices No Found, Please check The USB is plug in."));
		goto USB_EXIT_CLOSE_WIN;
	}

	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();
	
	ISP->UPDATE_RTC_USB();

	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;
#endif 
#if  0
	TB1.SetFaceColor(RGB(255, 255, 255), true);
	TB1.m_bTransparent = FALSE;
	TB1.m_bDontUseWinXPTheme = TRUE;
	TB1.m_bDrawFocus = FALSE;
#endif
	for (int i=0;i<64;i++)
	InitializeMyButton(TB[i]);

	LOGFONT fnt = { 0 };
	CFont* pFont = GetFont();
	if (NULL != pFont)
	{
		pFont->GetLogFont(&fnt);
		fnt.lfWeight = FW_HEAVY;
		fnt.lfHeight = 120;
		//
		if (m_fntBold.CreatePointFontIndirect(&fnt))
		{
			m_staSF.SetFont(&m_fntBold, TRUE);
			m_staIF.SetFont(&m_fntBold, TRUE);
			m_staFF.SetFont(&m_fntBold, TRUE);
	     }
     }


	return TRUE;  // return TRUE  unless you set the focus to a control
#if relase_mode
USB_EXIT_CLOSE_WIN:
	//close usb port
	ISP->CLOSE_USB_PORT();
	delete ISP;
	EndDialog(IDCANCEL);
	return FALSE;
#endif
}

void CnuvotonmagicboardutilDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		caboutbox dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CnuvotonmagicboardutilDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
#if 0
	CStatic* pwnd = (CStatic*)GetDlgItem(IDC_PIC);
	CImage image;
	image.Load(_T("bar.png"));
	HBITMAP hbmp = image.Detach();
	pwnd->SetBitmap(hbmp);
	pwnd->SetWindowPos(NULL, 0, 0, 100, 50, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOZORDER);
#endif
}

void CnuvotonmagicboardutilDlg::OnClose()
{
	Sleep(1);
	DestroyWindow();
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CnuvotonmagicboardutilDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CnuvotonmagicboardutilDlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	ISP_COMMAND* ISPA = new ISP_COMMAND();
#if 1
	if (ISPA->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXITa;
	}

	//START ;
	ISPA->SN_PACKAGE_USB();
	ISPA->SN_PACKAGE_USB();
	unsigned int temp = 0;
	temp = ISPA->CHECK_BOOT_USB();
	TRACE("Mode = 1, Run in APROM\n\r");
	TRACE("Mode = 2, Run in LDROM\n\r");
	TRACE("BOOT:0x%x\n\r", temp);
	if (temp == 2)
	{
		ISPA->RUN_TO_APROM_USB();
	}
USB_EXITa:
	//close usb port
	ISPA->CLOSE_USB_PORT();
#endif
	delete ISPA;
	if (temp == 2)
	{
		Sleep(500);
		AfxMessageBox(_T("Do software jumper to aprom!"));
	}

	
	CEdit* pEdit;
	pEdit = (CEdit *)GetDlgItem(IDC_EDIT1);
	CString str;
	pEdit->GetWindowText(str);
	TRACE("%s\n\r",str);
	if (str.IsEmpty()) {
		TRACE("string is empty\n");
		AfxMessageBox(_T("string is empty, please input char in the box"));
		return;
	}
	

	if (str.GetLength() > 48) {
		TRACE("string over 48\n");
		AfxMessageBox(_T("string over 48"));
		return;
	}

	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT_CLOSE_WIN;
	}

	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();

	if (ISP->CHECK_BOOT_USB() != 1)
	{
		TRACE("it is boot in ldrom\n\r");
		AfxMessageBox(_T("Please check boot in APROM"));
	
	}

	_TCHAR user_String[256]; 
	_tcscpy(user_String, str);
	ISP->WRITE_APROM_DATA_USB(user_String, str.GetLength());
	ISP->UPDATE_RTC_USB();

	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;
	AfxMessageBox(_T("Updated string done!"));
	return;
USB_EXIT_CLOSE_WIN:
	//close usb port
	ISP->CLOSE_USB_PORT();
	delete ISP;
	EndDialog(IDCANCEL);
	return ;

}


void CnuvotonmagicboardutilDlg::OnBnClickedButton3()
{

	// TODO: Add your control notification handler code here
	ISP_COMMAND* ISPA = new ISP_COMMAND();
#if 1
	if (ISPA->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXITa;
	}

	//START ;
	ISPA->SN_PACKAGE_USB();
	ISPA->SN_PACKAGE_USB();
	unsigned int temp = 0;
	temp = ISPA->CHECK_BOOT_USB();
	TRACE("Mode = 1, Run in APROM\n\r");
	TRACE("Mode = 2, Run in LDROM\n\r");
	TRACE("BOOT:0x%x\n\r", temp);	
	if (temp == 1)
	{
		ISPA->RUN_TO_LDROM_USB();
	}
USB_EXITa:
	//close usb port
	ISPA->CLOSE_USB_PORT();
#endif
	delete ISPA;
	if (temp == 1)
	{
		Sleep(500);
		AfxMessageBox(_T("Do software jumper, to ldrom!"));
	}
	TCHAR szFilter[] = _T("bin file(*.bin)|*.bin||");
 
	CFileDialog fileDlg(TRUE, _T("txt"), NULL, 0, szFilter, this);
	CString strFilePath;

 
	if (IDOK == fileDlg.DoModal())
	{		   
		strFilePath = fileDlg.GetPathName();
		TRACE(strFilePath);
	}
	else {
		return;
	}
	ISP_COMMAND *ISP = new ISP_COMMAND();

	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT;
	}
	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();

	_TCHAR filename[256]; 
	_tcscpy(filename, strFilePath);

	if (ISP->File_Open_APROM(filename) == RES_FILE_NO_FOUND)
	{
		
		TRACE("FILE NO FOUND\n\r");
		delete ISP;
		return ;
	}
	TRACE("File name: %s\n\r", filename);
	TRACE("File size: %d\n\r", ISP->file_size);
	TRACE("File checksum: %d\n\r", ISP->file_checksum);

	if (ISP->file_size > aprom_size_t)
	{
		TRACE("bin file over flash size\n\r");
		delete ISP;
		return ;
	}

	printf("File size: 0x%x\n\r", ISP->file_size);
	printf("File checksum: 0x%x\n\r", ISP->file_checksum);

ISP->APROM_AND_CHECKSUM();
ISP->file_size = 128 * 1024;
TRACE("aprom with check sum inside File size: %d\n\r", ISP->file_size);
TRACE("aprom with check sun inside File checksum: %d\n\r", ISP->file_checksum);

//CHECK FW
TRACE("FW version: 0x%x \n\r", ISP->READFW_VERSION_USB());
//CHECK PID
if (ISP->READ_PID_USB() == RES_FALSE)
{
	TRACE("CHIP NO FOUND\n\r");
	goto USB_EXIT;
}
if (ISP->CHECK_BOOT_USB() != 2)
{
	TRACE("it is boot in aprom\n\r");
	AfxMessageBox(_T("Please check boot in LDROM"));
	goto USB_EXIT;
}
//READ CONFIG
TRACE("config \n\r");
ISP->READ_CONFIG_USB();
CStatic* pStatic;
pStatic = (CStatic *)GetDlgItem(IDC_STATICISP);
pStatic->SetWindowText(_T("Do ISP Command"));
//test updata aprom
if (ISP->UPDATE_APROM_USB()== RES_PASS)
pStatic->SetWindowText(_T("ISP Done"));
else
pStatic->SetWindowText(_T("ISP False"));
//reboot mcu to aprom
ISP->RUN_TO_APROM_USB();
USB_EXIT:
//close usb port
ISP->CLOSE_USB_PORT();

delete ISP;

}


void CnuvotonmagicboardutilDlg::OnBnClickedButton5()
{
	// TODO: Add your control notification handler code here
	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT;
	}
	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();
	ISP->RUN_TO_LDROM_USB();

USB_EXIT:
	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;

	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton8()
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT;
	}
	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();
	ISP->RUN_TO_LDROM_USB();

USB_EXIT:
	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton4()
{
	// TODO: Add your control notification handler code here
	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT;
	}

	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();
	unsigned int temp = 0;
	temp = ISP->CHECK_BOOT_USB();
	TRACE("Mode = 1, Run in APROM\n\r");
	TRACE("Mode = 2, Run in LDROM\n\r");
	TRACE("BOOT:0x%x\n\r", temp);
	CStatic* pStatic;
	pStatic = (CStatic *)GetDlgItem(IDC_STATICBOOT);
	if (temp==1)
		pStatic->SetWindowText(_T("Run in APROM"));
	if (temp==2)
		pStatic->SetWindowText(_T("Run in LDROM"));
USB_EXIT:
	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;

}


void CnuvotonmagicboardutilDlg::OnBnClickedButton7()
{
	CString val = _T("");
	// TODO: Add your control notification handler code here
	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT;
	}

	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();


	unsigned int temp = ISP->READFW_VERSION_USB();
	TRACE("FW version: 0x%x \n\r", temp);
	CStatic* pStatic;
	pStatic = (CStatic *)GetDlgItem(IDC_STATICVERSION);

	val.Format(_T("0x%x"), temp);
	pStatic->SetWindowText(val);
USB_EXIT:
	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;
}

#pragma pack(push, 1) // Ensure structure alignment
typedef struct {
	uint16_t type;           
	uint32_t size;           
	uint16_t reserved1;      
	uint16_t reserved2;      
	uint32_t offset;         
	uint32_t header_size;    
	int32_t  width;          
	int32_t  height;         
	uint16_t planes;         
	uint16_t bpp;            
	uint32_t compression;    
	uint32_t img_size;       
	int32_t  x_ppm;          
	int32_t  y_ppm;          
	uint32_t color_used;     
	uint32_t color_important;
} BMPHeader;
#pragma pack(pop)
void CnuvotonmagicboardutilDlg::OnBnClickedButton2()
{
	TCHAR szFilter[] = _T("bmp file(*.bmp)|*.bmp||");

	CFileDialog fileDlg(TRUE, _T("open image  8x8 file"), NULL, 0, szFilter, this);
	CString strFilePath;

	if (IDOK == fileDlg.DoModal())
	{
		strFilePath = fileDlg.GetPathName();
		TRACE(strFilePath);
	}
	else {
		return;
	}
	FILE *file = _tfopen(strFilePath, _T("rb")); 
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file); 


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return ;
	}

	
	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8; 
	if (header.width % 8 != 0)
		row_size++; 


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return ;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	 }

#if 0
	if ((tempdata[0]&0x01)==0x01)
	((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(TRUE);
	else
	((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(FALSE);
	if ((tempdata[0] & 0x02) == 0x02)
		((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(TRUE);
	else
		((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(FALSE);
#endif 
#if 0
	BOOL itisChecked=false;
	itisChecked=IsDlgButtonChecked(IDC_CHECK1);
	TRACE("%d", itisChecked);
#endif
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton6()
{

	// TODO: Add your control notification handler code here
	ISP_COMMAND* ISPA = new ISP_COMMAND();
#if 1
	if (ISPA->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXITa;
	}

	//START ;
	ISPA->SN_PACKAGE_USB();
	ISPA->SN_PACKAGE_USB();
	unsigned int temp = 0;
	temp = ISPA->CHECK_BOOT_USB();
	TRACE("Mode = 1, Run in APROM\n\r");
	TRACE("Mode = 2, Run in LDROM\n\r");
	TRACE("BOOT:0x%x\n\r", temp);
	if (temp == 2)
	{
		ISPA->RUN_TO_APROM_USB();
	}
USB_EXITa:
	//close usb port
	ISPA->CLOSE_USB_PORT();
#endif
	delete ISPA;
	if (temp == 2)
	{
		Sleep(500);
		AfxMessageBox(_T("Do software jumper to aprom!"));
	}


	unsigned char tempdata[8];

	for (int i = 0; i < 8; ++i)
	{
		tempdata[i] = 0; 
	}

	for (int i = 0; i < 64; ++i)
	{
		//UINT nIDC = IDC_CHECK1 + i; 

		//BOOL bCheck = ((CButton*)GetDlgItem(nIDC))->GetCheck(); // ??checkbox??
#if 1
		if (image_array[i]==TRUE)
		{
			int index = i / 8;
			int bit = i % 8;
			tempdata[index] |= (1 << bit); 
		}
#endif
	}
	for (int i = 0; i < 8; i++)
		TRACE("%d=0x%x\n\r", i, tempdata[i]);
	// TODO: Add your control notification handler code here
	ISP_COMMAND *ISP = new ISP_COMMAND();
#if 1
	if (ISP->OPEN_USBPORT() != RES_CONNECT)
	{
		TRACE("USB NO FOUND\n\r");
		AfxMessageBox(_T("USB NO FOUND"));
		goto USB_EXIT_CLOSE_WIN;
	}

	//START ;
	ISP->SN_PACKAGE_USB();
	ISP->SN_PACKAGE_USB();
	if (ISP->CHECK_BOOT_USB() != 1)
	{
		TRACE("it is boot in ldrom\n\r");
		AfxMessageBox(_T("Please check boot in APROM"));
		
	}
	ISP->WRITE_APROM_IMG_RAWDATA_USB(tempdata,8);
	ISP->UPDATE_RTC_USB();

	//close usb port
	ISP->CLOSE_USB_PORT();
#endif
	delete ISP;
	AfxMessageBox(_T("Updated image done!"));
	return;
USB_EXIT_CLOSE_WIN:
	//close usb port
	ISP->CLOSE_USB_PORT();
	delete ISP;
	EndDialog(IDCANCEL);
	return;
}



void CnuvotonmagicboardutilDlg::OnBnClickedButton9()
{
	FILE *file = fopen("pixelart/deer.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];

	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton10()
{
	FILE *file = fopen("pixelart/ghost.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton11()
{
	FILE *file = fopen("pixelart/love.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton12()
{
	FILE *file = fopen("pixelart/monster_1.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton13()
{
	FILE *file = fopen("pixelart/monster_2.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton14()
{
	FILE *file = fopen("pixelart/monster_3.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton15()
{
	FILE *file = fopen("pixelart/monster_4.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton16()
{
	FILE *file = fopen("pixelart/monster_5.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];


	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}


void CnuvotonmagicboardutilDlg::OnBnClickedButton17()
{
	FILE *file = fopen("pixelart/monster_6.bmp", "rb");
	if (file == NULL) {
		TRACE("Error opening file");
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	BMPHeader header;
	fread(&header, sizeof(header), 1, file);


	if (header.type != 0x4D42) {
		fprintf(stderr, "Not a BMP file\n");
		fclose(file);
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}


	TRACE("Width: %d\n", header.width);
	TRACE("Height: %d\n", header.height);
	TRACE("Bits per pixel: %d\n", header.bpp);
	if ((header.width != 8) || (header.height != 8))
	{
		AfxMessageBox(_T("Load 8x8 bmp file false"));
		return;
	}

	int bytes_per_pixel = header.bpp / 8;
	int row_size = header.width / 8;
	if (header.width % 8 != 0)
		row_size++;


	unsigned char *data = (unsigned char*)malloc(4 * header.height);
	if (data == NULL) {
		TRACE("Memory allocation failed");
		fclose(file);
		AfxMessageBox(_T("Load bmp file false"));
		return;
	}

	fseek(file, header.offset, SEEK_SET);
	fread(data, 4 * header.height, 1, file);
	//for (int i = 0; i < 32; i++)
		//TRACE("%d=0x%x\n\r", i, data[i]);
	unsigned char tempdata[8] = { 0 };
	tempdata[7] = ~data[0];
	tempdata[6] = ~data[4];
	tempdata[5] = ~data[8];
	tempdata[4] = ~data[12];
	tempdata[3] = ~data[16],
	tempdata[2] = ~data[20];
	tempdata[1] = ~data[24];
	tempdata[0] = ~data[28];

	for (int i = 0; i < 64; i++)
		InitializeMyButton(TB[i]);
	for (int i = 0; i < 8; ++i)
	{
		for (int j = 0; j < 8; ++j)
		{
			BOOL bCheck = (tempdata[i] & (1 << j)) != 0;
			//UINT nIDC = IDC_TB1 + (i * 8) + j;
			UINT nIDC = (i * 8) + j;
			//((CButton*)GetDlgItem(nIDC))->SetCheck(bCheck);

			if (bCheck == TRUE)
			{
				Button_ON(TB[nIDC]);
				image_array[nIDC] = TRUE;
			}
			else
			{
				Button_OFF(TB[nIDC]);
				image_array[nIDC] = FALSE;
			}

		}
	}
	// TODO: Add your control notification handler code here
}





#if 0
unsigned char vol = 0;
void CnuvotonmagicboardutilDlg::OnBnClickedTb1()
{

	if (vol == 0)
	{
		//TB1.SetFaceColor(RGB(255, 255, 255), true);
		//TB1.m_bTransparent = FALSE;
		//TB1.m_bDontUseWinXPTheme = TRUE;
		//TB1.m_bDrawFocus = FALSE;
		vol = 1;
	}
	else
	{
		//TB1.SetFaceColor(RGB(0, 0, 0), true);
		//TB1.m_bTransparent = FALSE;
		//TB1.m_bDontUseWinXPTheme = TRUE;
		//TB1.m_bDrawFocus = FALSE;
		vol = 0;
	}
	// TODO: Add your control notification handler code here
}

#endif


void CnuvotonmagicboardutilDlg::TBOnButtonClick(unsigned int ID)
{
	TRACE("id=%d\n\r", ID);
	if (image_array[(ID - IDC_TB1)] == FALSE)
	{
		Button_ON(TB[ID - IDC_TB1]);
		image_array[ID - IDC_TB1] = TRUE;
	}
	else
	{
		Button_OFF(TB[ID - IDC_TB1]);
		image_array[ID - IDC_TB1] = FALSE;
	}
}