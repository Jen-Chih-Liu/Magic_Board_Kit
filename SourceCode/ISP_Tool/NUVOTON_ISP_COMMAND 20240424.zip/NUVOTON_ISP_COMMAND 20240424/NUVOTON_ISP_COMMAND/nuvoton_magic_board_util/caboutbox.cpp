// caboutbox.cpp : implementation file
//

#include "pch.h"
#include "NUVOTON_Magic_Board_Util.h"
#include "caboutbox.h"
#include "afxdialogex.h"


// caboutbox dialog

IMPLEMENT_DYNAMIC(caboutbox, CDialog)

caboutbox::caboutbox(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_ABOUTBOX, pParent)
{

}

caboutbox::~caboutbox()
{
}

void caboutbox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(caboutbox, CDialog)
END_MESSAGE_MAP()


// caboutbox message handlers
