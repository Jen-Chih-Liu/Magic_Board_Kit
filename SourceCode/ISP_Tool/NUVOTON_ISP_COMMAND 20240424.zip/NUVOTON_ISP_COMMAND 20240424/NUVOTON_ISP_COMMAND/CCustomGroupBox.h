#pragma once
#include <afxbutton.h>

class CCustomGroupBox : public CButton
{
public:
    CCustomGroupBox();
    virtual ~CCustomGroupBox();

protected:
    DECLARE_MESSAGE_MAP()

public:
    afx_msg void OnPaint();

protected:
    DECLARE_DYNAMIC(CCustomGroupBox)
};