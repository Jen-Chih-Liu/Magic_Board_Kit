//Tetris porting
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "NU_M258KG.h"
volatile uint32_t g_u8IsWDTTimeoutINT;
volatile uint8_t g_u8IsWDTWakeupINT;
volatile uint8_t g_u8IsWDTReset;
volatile uint32_t g_u32WDTINTCounts;
/**
 * @brief       IRQ Handler for WDT Interrupt
 *
 * @param       None
 *
 * @return      None
 *
 * @details     The WDT_IRQHandler is default IRQ of WDT, declared in startup_M251.s .
 */
void WDT_IRQHandler(void)
{
    if (g_u32WDTINTCounts < 1) //
        WDT_RESET_COUNTER();

    g_u8IsWDTTimeoutINT = 1;
   
    if (WDT_GET_TIMEOUT_INT_FLAG() == 1)
    {
        /* Clear WDT time-out interrupt flag */
        WDT_CLEAR_TIMEOUT_INT_FLAG();
        g_u32WDTINTCounts++;
    }

    if (WDT_GET_TIMEOUT_WAKEUP_FLAG() == 1)
    {
        /* Clear WDT time-out wake-up flag */
        WDT_CLEAR_TIMEOUT_WAKEUP_FLAG();
        g_u8IsWDTWakeupINT = 1;
    }
}
void WDT_Init(void)
{
#if 1
    /* Enable WDT NVIC */
    NVIC_EnableIRQ(WDT_IRQn);

    /* Because of all bits can be written in WDT Control Register are write-protected;
       To program it needs to disable register protection first. */
    SYS_UnlockReg();

    /* Configure WDT settings and start WDT counting */
    WDT_Open(WDT_TIMEOUT_2POW20, WDT_RESET_DELAY_1026CLK, TRUE, TRUE);  //Timeout interval 27.307 s   Reset interval 27.333 s

    /* Enable WDT interrupt function */
    WDT_EnableInt();
#endif
}
