#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "NU_M258KG.h"

volatile uint8_t u8EventTMR0Timeout = 0;
volatile uint32_t u32EventTMR0Count = 0;

void TMR0_IRQHandler(void)
{ 
    u8EventTMR0Timeout = 1;

    u32EventTMR0Count++;

    // Clear wake up flag
    TIMER_ClearWakeupFlag(TIMER0);
    // Clear interrupt flag
    TIMER_ClearIntFlag(TIMER0);
 
}

void TMR0_Init(void)
{
    /* Initial Timer0 to periodic mode with 1Hz, since system is fast (48MHz)
    and timer is slow (38.4kHz), and following function calls all modified timer's
    CTL register, so add extra delay between each function call and make sure the
    setting take effect */
    if (TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 2) != 1)
    {
        //printf("Set the frequency different from the user\n");
    }

    CLK_SysTickDelay(50);

    /* Enable timer wake up system */
    TIMER_EnableWakeup(TIMER0);
    CLK_SysTickDelay(50);

    /* Enable Timer0 interrupt */
    TIMER_EnableInt(TIMER0);
    CLK_SysTickDelay(50);

    NVIC_EnableIRQ(TMR0_IRQn);

    /* Start Timer0 counting */
    TIMER_Start(TIMER0);
    CLK_SysTickDelay(50);
}
