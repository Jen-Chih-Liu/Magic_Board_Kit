///******************************************************************************
// * @file     TK_Command.c
// * @version  V1.00
// * @brief    Touch-key function
// *
// *
// * @copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
// *
// *****************************************************************************/
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "TK_Demo.h"
#include "lcdlib.h"
#include "..\NU_M258KG.h"
////-----------------------------------------------------------------------------
//// Variable Declaration
////-----------------------------------------------------------------------------
void switch_HCLK_to_MIRC(void)
{
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_MIRC, CLK_CLKDIV0_HCLK(1));
    CLK_DisableXtalRC(CLK_PWRCTL_HIRCEN_Msk);
    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    SystemCoreClockUpdate();

    /* Init systick 20ms/tick */
    Init_SysTick();
    /* Install Tick Event Handler */
    TickCallbackFun();
    TMR0_Init();
}
void switch_HCLK_to_HIRC(void)
{
    /* Enable HIRC clock (Internal RC 48MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);
    /* Wait for HIRC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HIRC, CLK_CLKDIV0_HCLK(1));
    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    SystemCoreClockUpdate();

    /* Init systick 20ms/tick */
    Init_SysTick();
    /* Install Tick Event Handler */
    TickCallbackFun();
    TMR0_Init();
}
// a dummy function
void null_func(void)
{
    return;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Touch event                                                                                                                                       */
/*---------------------------------------------------------------------------------------------------------*/
void tk_func2(void)//TK_Right
{
    if (g_u8Scenario == TetrisScenario)
    {
        Tetris_TK_Event(2);
        TickClearTick(2);//u8EventUntouched ID  //Reset untouch tick
    }
    else
    {

        g_u8PageIdx++;
        g_u8PageIdx = g_u8PageIdx % 3;

        switch (g_u8PageIdx)
        {
            default:
            case 0:
                String_MarqueeSetting.StartIdx = 0;
                String_MarqueeSetting.NextStartIdx = 0;
                String_MarqueeSetting.ColumnIdx = 0;
                break;

            case 1:
                Time_MarqueeSetting.StartIdx = 0;
                Time_MarqueeSetting.NextStartIdx = 0;
                Time_MarqueeSetting.ColumnIdx = 0;
                break;

            case 2:
                Image_MarqueeSetting.StartIdx = 0;
                Image_MarqueeSetting.NextStartIdx = 0;
                Image_MarqueeSetting.ColumnIdx = 0;
                break;
        }
    }

    return;
}



void tk_func4(void)//TK_Left
{
    if (g_u8Scenario == TetrisScenario)
    {
        Tetris_TK_Event(4);
        TickClearTick(2);//u8EventUntouched ID  //Reset untouch tick
    }
    else
    {
        if (g_u8PageIdx > 0) g_u8PageIdx--;
        else g_u8PageIdx = 2;

        switch (g_u8PageIdx)
        {
            default:
            case 0:
                String_MarqueeSetting.StartIdx = 0;
                String_MarqueeSetting.NextStartIdx = 0;
                String_MarqueeSetting.ColumnIdx = 0;
                break;

            case 1:
                Time_MarqueeSetting.StartIdx = 0;
                Time_MarqueeSetting.NextStartIdx = 0;
                Time_MarqueeSetting.ColumnIdx = 0;
                break;

            case 2:
                Image_MarqueeSetting.StartIdx = 0;
                Image_MarqueeSetting.NextStartIdx = 0;
                Image_MarqueeSetting.ColumnIdx = 0;
                break;
        }
    }

    return;
}
void tk_func3(void)//TK_Rotate
{
    if (Device_Config.IsPowerON == PWR_ON) //Power On
    {
        if (g_u8Scenario == TetrisScenario)
        {
            switch_HCLK_to_HIRC();

            Tetris_TK_Event(3);
            TickClearTick(2);//u8EventUntouched ID  //Reset untouch tick
        }
        else//From Marquee switch to Tetris
        {
            switch_HCLK_to_MIRC();

            g_u8Scenario = TetrisScenario;
            LCD_Tetris_Frame();
            Tetris_init();
            Tetris_loop();
        }
    }

    return;
}

void tk_func5(void)//TK_Right
{
    //#ifdef USB_ON

    if (Device_Config.IsDebugMode == USB_MODE)
    {
        Device_Config.IsDebugMode = DEBUG_MODE;
        CLK_SysTickDelay(10);
        //Disable USB function
        CLK_DisableModuleClock(USBD_MODULE);
        CLK_DisableModuleClock(EXST_MODULE);
        /* Clear SOF */
        USBD_CLR_INT_FLAG(USBD_INTSTS_SOFIF_Msk);
        /* Disable software-disconnect function */
        USBD_CLR_SE0();
        CLK_SysTickDelay(10);
        LCDLIB_SetSymbol(SYMBOL_WIFI, 1);
    }
    else//Device_Config.IsDebugMode == Debug_MODE
    {
        Device_Config.IsDebugMode = USB_MODE;
        CLK_SysTickDelay(10);
        //Enable USB function
        CLK_EnableModuleClock(USBD_MODULE);
        CLK_EnableModuleClock(EXST_MODULE);
        USBD_Init();
        CLK_SysTickDelay(10);
        LCDLIB_SetSymbol(SYMBOL_WIFI, 0);
    }

    //#endif
    return;
}
void tk_func7(void)//TK_Left
{
    if (Device_Config.IsPowerON == PWR_ON) //Power On
    {
        switch_HCLK_to_MIRC();


        Device_Config.IsPowerON = PWR_OFF;
        Tetris_ClearAllBlock();
        LCDLIB_SetSymbol(SYMBOL_NVT, 0);
        LCDLIB_SetSymbol(SYMBOL_SCORE, 0);
        LCDLIB_SetSymbol(SYMBOL_NEXT, 0);
        LCD_ClearNumber(ZONE_SCORE_DIGIT);

        if (Device_Config.IsDebugMode == USB_MODE)
        {
            Device_Config.IsDebugMode = DEBUG_MODE;
            CLK_SysTickDelay(10);
            //Disable USB function
            CLK_DisableModuleClock(USBD_MODULE);
            CLK_DisableModuleClock(EXST_MODULE);
            /* Clear SOF */
            USBD_CLR_INT_FLAG(USBD_INTSTS_SOFIF_Msk);
            /* Disable software-disconnect function */
            USBD_CLR_SE0();
            CLK_SysTickDelay(10);
            LCDLIB_SetSymbol(SYMBOL_WIFI, 1);
        }
    }
    else//Device_Config.IsPowerON == 0 //Power Off
    {
        switch_HCLK_to_HIRC();

        Device_Config.IsPowerON = PWR_ON;
        LCDLIB_SetSymbol(SYMBOL_NVT, 1);
        g_u8Scenario = MarqueeScenario;
        LCD_Marquee_Frame();

        if (Device_Config.IsDebugMode == DEBUG_MODE)
        {

            Device_Config.IsDebugMode = USB_MODE;
            CLK_SysTickDelay(10);
            //Enable USB function
            CLK_EnableModuleClock(USBD_MODULE);
            CLK_EnableModuleClock(EXST_MODULE);
            USBD_Init();
            CLK_SysTickDelay(10);
            LCDLIB_SetSymbol(SYMBOL_WIFI, 0);
        }
    }

    return;
}
VoidFunc2 TKFunc[8] =
{
    &null_func,  &null_func,   &tk_func2,  &tk_func3, &tk_func4, &tk_func5, &null_func, &tk_func7
};

