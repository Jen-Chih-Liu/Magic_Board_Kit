/**************************************************************************//**
 * @file     NU_M258KG.h
 * @version  V1.00
 * @brief    For NuMaker-M258KG header file.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#ifndef _NU_M258_KG_H_
#define _NU_M258_KG_H_


#include "tklib.h"
#include "lcdlib.h"
#include ".\USBD_Drv\targetdev.h"
#include ".\USBD_Drv\hid_transfer.h"
#include ".\USBD_Drv\isp_user.h"
#include ".\Touchkey\TK_Demo.h"

////-----------------------------------------------------------------------------
//// Variable Declaration
////-----------------------------------------------------------------------------
#define TK2 2
#define TK3 3
#define TK4 4

#define MarqueeScenario 0
#define TetrisScenario 1

#define PWR_ON 1
#define PWR_OFF 0

#define DEBUG_MODE 1
#define USB_MODE 0
/* main.c */
typedef enum
{
    eMAIN_APP_IDLE_STATE,
    eMAIN_APP_TK_PRESS_STATE,
    eMAIN_APP_TK_RELEASE_STATE,
    eMAIN_APP_TK_UNTOUCH_STATE,
    eMAIN_APP_TK_LONG_STATE,
} E_MAIN_APP_STATE;

/* Marquee.c */
typedef void(*VoidFunc)(void);
extern VoidFunc MarqueeFunc[3];

struct Marquee_Setting_Tag;
typedef struct Marquee_Setting_Tag
{
    uint8_t   StartIdx;
    uint8_t   NextStartIdx;
    uint8_t   ColumnIdx;
    uint8_t   DataLength;
    uint8_t   *DataBuf;
} Marquee_Setting_T;

extern __attribute__((aligned(4))) volatile Marquee_Setting_T String_MarqueeSetting;
extern __attribute__((aligned(4))) volatile Marquee_Setting_T Time_MarqueeSetting;
extern __attribute__((aligned(4))) volatile Marquee_Setting_T Image_MarqueeSetting;

struct Device_Tag;
typedef struct Device_Tag
{
    uint8_t   IsPowerON;
    uint8_t   IsDebugMode;
} Device_T;

extern Device_T Device_Config;

/* main.c */
extern uint8_t   g_u8Scenario;
extern uint8_t   g_u8PageIdx;
void USBD_Init(void);
/* TK_Event.c */
typedef void(*VoidFunc2)();
extern VoidFunc2 TKFunc[8];

extern uint8_t WordTable[101][6] ;
extern volatile uint8_t u8EventTMR0Timeout;

/* isp_user.c */
extern uint8_t bUsbTimeDataReady;
extern uint8_t bUsbStringDataReady;
extern uint8_t bUsbImageDataReady;

/* RTC_Drv.c */
extern volatile int32_t  g_i32Alarm ;
extern S_RTC_TIME_DATA_T sCurTime;

/* LCD_NK.c */
void LCD_Init_Setting(void);
void LCD_PowerOn(void);
void LCD_Battery_State(uint32_t u32Vbat);
void LCD_Tetris_Frame(void);
void LCD_Marquee_Frame(void);
void LCD_ClearNumber(uint32_t u32Zone);

/* RTC_Drv.c */
void RTC_from_LXT();
void RTC_Init();
void RTC_Update();

/* Tetris.c */
void Tetris_init(void);
void Tetris_loop(void);
void Tetris_TK_Event(int8_t channel);
void Tetris_ClearAllBlock(void);

/* Marquee.c */
void String_Marquee_Init(void);
void Image_Marquee_Init(void);
void Time_Marquee_Init(void);

/* Timer_Wakeup.c */
void TMR0_Init(void);
extern volatile uint8_t u8EventTMR0Timeout;
extern volatile uint32_t u32EventTMR0Count;

/* ADC_Drv.c */
void ADC_Init(void);
uint32_t ADC_Calculate_VBAT(void);

void WDT_Init(void);
extern volatile uint32_t g_u8IsWDTTimeoutINT;
extern volatile uint8_t g_u8IsWDTWakeupINT;
extern volatile uint32_t g_u32WDTINTCounts;
extern volatile uint8_t g_u8IsWDTReset;


#endif
