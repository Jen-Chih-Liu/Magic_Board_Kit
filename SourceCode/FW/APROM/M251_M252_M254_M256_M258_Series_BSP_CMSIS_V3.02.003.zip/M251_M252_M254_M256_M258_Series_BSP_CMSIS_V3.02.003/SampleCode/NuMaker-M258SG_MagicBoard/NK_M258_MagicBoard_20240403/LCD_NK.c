/**************************************************************************//**
 * @file     LCD_NK.c
 * @version  V1.00
 * @brief    LCD Initial & Frame config.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "NuMicro.h"
#include "NU_M258KG.h"
#include "tklib.h"
#include "lcdlib.h"
uint32_t lcd_data[12];
static S_LCD_CFG_T g_LCDCfg =
{
    __LIRC,                     /*!< LCD clock source frequency */
    LCD_COM_DUTY_1_8,           /*!< COM duty */
    LCD_BIAS_LV_1_4,            /*!< Bias level */
    64,                         /*!< Operation frame rate */
    LCD_WAVEFORM_TYPE_B_NORMAL, /*!< Waveform type */
    LCD_DISABLE_ALL_INT,        /*!< Interrupt source */
    LCD_PWR_SAVING_BUF_MODE,// LCD_HIGH_DRIVING_OFF_AND_BUF_ON_AND_PWR_SAVING,//LCD_PWR_SAVING_BUF_MODE, /*!< Driving mode */
    LCD_VOLTAGE_SOURCE_AVDD,      /*!< Voltage source */
    //LCD_VOLTAGE_SOURCE_CP,
};

void LCD_IO_Init(void)
{
    /* COM 0~3 */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB5MFP_Msk | SYS_GPB_MFPL_PB4MFP_Msk | SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk)) |
                    (SYS_GPB_MFPL_PB5MFP_LCD_COM0 | SYS_GPB_MFPL_PB4MFP_LCD_COM1 | SYS_GPB_MFPL_PB3MFP_LCD_COM2 | SYS_GPB_MFPL_PB2MFP_LCD_COM3);

    /* COM 4~7 */
    SYS->GPC_MFPL = (SYS->GPC_MFPL & ~(SYS_GPC_MFPL_PC5MFP_Msk | SYS_GPC_MFPL_PC4MFP_Msk | SYS_GPC_MFPL_PC3MFP_Msk | SYS_GPC_MFPL_PC2MFP_Msk)) |
                    (SYS_GPC_MFPL_PC5MFP_LCD_COM4 | SYS_GPC_MFPL_PC4MFP_LCD_COM5 | SYS_GPC_MFPL_PC3MFP_LCD_COM6 | SYS_GPC_MFPL_PC2MFP_LCD_COM7);


    /* SEG 0~1 */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB0MFP_Msk | SYS_GPB_MFPL_PB1MFP_Msk)) |
                    (SYS_GPB_MFPL_PB0MFP_LCD_SEG0 | SYS_GPB_MFPL_PB1MFP_LCD_SEG1);

    /* SEG 4~13 */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB6MFP_Msk | SYS_GPB_MFPL_PB7MFP_Msk)) |
                    (SYS_GPB_MFPL_PB6MFP_LCD_SEG4 | SYS_GPB_MFPL_PB7MFP_LCD_SEG5);
    SYS->GPB_MFPH = (SYS->GPB_MFPH & ~(SYS_GPB_MFPH_PB8MFP_Msk | SYS_GPB_MFPH_PB9MFP_Msk | SYS_GPB_MFPH_PB10MFP_Msk | SYS_GPB_MFPH_PB11MFP_Msk |
                                       SYS_GPB_MFPH_PB12MFP_Msk | SYS_GPB_MFPH_PB13MFP_Msk | SYS_GPB_MFPH_PB14MFP_Msk | SYS_GPB_MFPH_PB15MFP_Msk)) |
                    (SYS_GPB_MFPH_PB8MFP_LCD_SEG6 | SYS_GPB_MFPH_PB9MFP_LCD_SEG7 | SYS_GPB_MFPH_PB10MFP_LCD_SEG8 | SYS_GPB_MFPH_PB11MFP_LCD_SEG9 |
                     SYS_GPB_MFPH_PB12MFP_LCD_SEG10 | SYS_GPB_MFPH_PB13MFP_LCD_SEG11 | SYS_GPB_MFPH_PB14MFP_LCD_SEG12 | SYS_GPB_MFPH_PB15MFP_LCD_SEG13);

    /* SEG 22~25 */
    SYS->GPD_MFPL = (SYS->GPD_MFPL & ~(SYS_GPD_MFPL_PD0MFP_Msk | SYS_GPD_MFPL_PD1MFP_Msk | SYS_GPD_MFPL_PD2MFP_Msk | SYS_GPD_MFPL_PD3MFP_Msk)) |
                    (SYS_GPD_MFPL_PD0MFP_LCD_SEG22 | SYS_GPD_MFPL_PD1MFP_LCD_SEG23 | SYS_GPD_MFPL_PD2MFP_LCD_SEG24 | SYS_GPD_MFPL_PD3MFP_LCD_SEG25);
    /* SEG 26~27 */
    SYS->GPC_MFPL = (SYS->GPC_MFPL & ~(SYS_GPC_MFPL_PC0MFP_Msk | SYS_GPC_MFPL_PC1MFP_Msk)) |
                    (SYS_GPC_MFPL_PC0MFP_LCD_SEG26 | SYS_GPC_MFPL_PC1MFP_LCD_SEG27);

    /* SEG 36~37 */
    SYS->GPA_MFPL = (SYS->GPA_MFPL & ~(SYS_GPA_MFPL_PA6MFP_Msk | SYS_GPA_MFPL_PA7MFP_Msk)) |
                    (SYS_GPA_MFPL_PA6MFP_LCD_SEG36 | SYS_GPA_MFPL_PA7MFP_LCD_SEG37);
    /* SEG 38~39 */
    SYS->GPC_MFPL = (SYS->GPC_MFPL & ~(SYS_GPC_MFPL_PC6MFP_Msk | SYS_GPC_MFPL_PC7MFP_Msk)) |
                    (SYS_GPC_MFPL_PC6MFP_LCD_SEG38 | SYS_GPC_MFPL_PC7MFP_LCD_SEG39);
    /* SEG 14 */
    SYS->GPC_MFPH = (SYS->GPC_MFPH & ~(SYS_GPC_MFPH_PC14MFP_Msk)) |
                    (SYS_GPC_MFPH_PC14MFP_LCD_SEG14);

    /* SEG 35 */
    SYS->GPF_MFPH = (SYS->GPF_MFPH & ~(SYS_GPF_MFPH_PF15MFP_Msk)) |
                    (SYS_GPF_MFPH_PF15MFP_LCD_SEG35);

    /* Reset LCD module */
    SYS_ResetModule(LCD_RST);

    /* Disable LCD GPIO pins digital input path to avoid the leakage current */
    GPIO_DISABLE_DIGITAL_PATH(PA, BIT6 | BIT7);
    GPIO_DISABLE_DIGITAL_PATH(PB, BIT5 | BIT4 | BIT3 | BIT2 | BIT1 | BIT0 | BIT6 | BIT7 | BIT8 | BIT9 | BIT10 | BIT11 | BIT12 | BIT13 | BIT14 | BIT15);
    GPIO_DISABLE_DIGITAL_PATH(PC, BIT14 | BIT6 | BIT7 | BIT5 | BIT4 | BIT3 | BIT2 | BIT1 | BIT0);
    GPIO_DISABLE_DIGITAL_PATH(PD, BIT3 | BIT2 | BIT1 | BIT0);
    GPIO_DISABLE_DIGITAL_PATH(PF, BIT15);
}

//----------------------------------------------------------------------------------------------//
void LCD_Init_Setting(void)
{

    /* As defaut all multi function define as GPIO */
    LCD_IO_Init();

    /* LCD Initialize and calculate real frame rate */
    LCD_Open(&g_LCDCfg);

    /* PE.8 PE.9 PE.10 PE.11 Output Select COM0 COM1 COM2 COM3 */
    LCD_OUTPUT_SET(LCD_OUTPUT_SEL24_TO_COM4 | LCD_OUTPUT_SEL25_TO_COM5 | LCD_OUTPUT_SEL26_TO_COM6 | LCD_OUTPUT_SEL27_TO_COM7 |
                   LCD_OUTPUT_SEL28_TO_SEG27 | LCD_OUTPUT_SEL29_TO_SEG26 | LCD_OUTPUT_SEL41_TO_SEG14 | LCD_OUTPUT_SEL42_TO_SEG13 |
                   LCD_OUTPUT_SEL47_TO_SEG8 | LCD_OUTPUT_SEL48_TO_SEG7 | LCD_OUTPUT_SEL49_TO_SEG6);

    LCD_SetSavingMode(LCD_PWR_SAVING_BUF_MODE, LCD_PWR_SAVING_LEVEL0);

    /* Enable LCD display */
    LCD_ENABLE_DISPLAY();
}
void LCD_BackupPixel(void)
{

    for (int i = 0; i < 12; i++)
    {
        lcd_data[i] = LCD->DATA[i];
    }

}
void LCD_RestorePixel(void)
{

    for (int i = 0; i < 12; i++)
    {
        LCD->DATA[i] = lcd_data[i];
    }

}
void LCD_Battery_State(uint32_t u32Vbat)
{
    LCDLIB_SetSymbol(SYMBOL_BAT_FRAME, 1);

    if (u32Vbat <= 2500)
    {
        if ((LCD->DSET & LCD_DSET_VSRC_Msk) == LCD_VOLTAGE_SOURCE_AVDD)
        {
            LCD_BackupPixel();
            g_LCDCfg.u32VSrc = LCD_VOLTAGE_SOURCE_CP;
            LCD_SET_CP_VOLTAGE(LCD_CP_VOLTAGE_LV_0);
            LCD_Init_Setting();
            LCD_RestorePixel();
        }

        LCDLIB_SetSymbol(SYMBOL_BAT_1, 0);
        LCDLIB_SetSymbol(SYMBOL_BAT_2, 0);
        LCDLIB_SetSymbol(SYMBOL_BAT_3, 0);
    }
    else if (u32Vbat > 2500 && u32Vbat <= 2625)//Vbat = 2250~2500mV
    {
        if ((LCD->DSET & LCD_DSET_VSRC_Msk) == LCD_VOLTAGE_SOURCE_AVDD)
        {
            LCD_BackupPixel();
            g_LCDCfg.u32VSrc = LCD_VOLTAGE_SOURCE_CP;
            LCD_SET_CP_VOLTAGE(LCD_CP_VOLTAGE_LV_0);
            LCD_Init_Setting();
            LCD_RestorePixel();
        }

        LCDLIB_SetSymbol(SYMBOL_BAT_1, 1);
        LCDLIB_SetSymbol(SYMBOL_BAT_2, 0);
        LCDLIB_SetSymbol(SYMBOL_BAT_3, 0);
    }
    else if (u32Vbat > 2625 && u32Vbat <= 2750)//Vbat = 2250~2750mV
    {
        if ((LCD->DSET & LCD_DSET_VSRC_Msk) == LCD_VOLTAGE_SOURCE_AVDD)
        {
            LCD_BackupPixel();
            g_LCDCfg.u32VSrc = LCD_VOLTAGE_SOURCE_CP;
            LCD_SET_CP_VOLTAGE(LCD_CP_VOLTAGE_LV_0);
            LCD_Init_Setting();
            LCD_RestorePixel();
        }

        LCDLIB_SetSymbol(SYMBOL_BAT_1, 1);
        LCDLIB_SetSymbol(SYMBOL_BAT_2, 1);
        LCDLIB_SetSymbol(SYMBOL_BAT_3, 0);


    }
    else if (u32Vbat > 2750)//Vbat = 2750~mV
    {
        if ((LCD->DSET & LCD_DSET_VSRC_Msk) == LCD_VOLTAGE_SOURCE_CP)
        {
            LCD_BackupPixel();
            g_LCDCfg.u32VSrc = LCD_VOLTAGE_SOURCE_AVDD;
            LCD_SetSavingMode(LCD_PWR_SAVING_BUF_MODE, LCD_PWR_SAVING_LEVEL0);
            LCD_Init_Setting();
            LCD_RestorePixel();
        }

        LCDLIB_SetSymbol(SYMBOL_BAT_1, 1);
        LCDLIB_SetSymbol(SYMBOL_BAT_2, 1);
        LCDLIB_SetSymbol(SYMBOL_BAT_3, 1);
    }
}

void LCD_PowerOn(void)
{
    LCDLIB_SetSymbol(SYMBOL_NVT, 1);
    LCDLIB_SetSymbol(SYMBOL_LINE, 1);
    LCDLIB_SetSymbol(SYMBOL_TIME, 1);
    LCDLIB_SetSymbol(SYMBOL_COL, 1);
    LCDLIB_PrintNumber(ZONE_TIME_DIGIT, sCurTime.u32Hour * 100 + sCurTime.u32Minute);
}

void LCD_Tetris_Frame(void)
{
    LCDLIB_SetSymbol(SYMBOL_SCORE, 1);
    LCDLIB_SetSymbol(SYMBOL_NEXT, 1);
    LCDLIB_PrintNumber(ZONE_SCORE_DIGIT, 0);
}

void LCD_ClearNumber(uint32_t u32Zone)
{
    uint32_t    i;
    uint32_t    com, seg;

    /* Fill out all characters on display */
    uint32_t index;

    index = g_LCDZoneInfo[u32Zone].u8LCDDispTableNum;

    while (index != 0)
    {
        index--;

        for (i = 0; i < g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum; i++)
        {
            com = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 0);
            seg = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 1);

            /* Turn off display */
            LCD_SetPixel(com, seg, 0);
        }
    }
}
void LCD_Marquee_Frame(void)
{
    String_MarqueeSetting.StartIdx = 0;
    String_MarqueeSetting.NextStartIdx = 0;
    String_MarqueeSetting.ColumnIdx = 0;

    Time_MarqueeSetting.StartIdx = 0;
    Time_MarqueeSetting.NextStartIdx = 0;
    Time_MarqueeSetting.ColumnIdx = 0;

    Image_MarqueeSetting.StartIdx = 0;
    Image_MarqueeSetting.NextStartIdx = 0;
    Image_MarqueeSetting.ColumnIdx = 0;

    LCDLIB_SetSymbol(SYMBOL_SCORE, 0);
    LCDLIB_SetSymbol(SYMBOL_NEXT, 0);
    LCD_ClearNumber(ZONE_SCORE_DIGIT);
}