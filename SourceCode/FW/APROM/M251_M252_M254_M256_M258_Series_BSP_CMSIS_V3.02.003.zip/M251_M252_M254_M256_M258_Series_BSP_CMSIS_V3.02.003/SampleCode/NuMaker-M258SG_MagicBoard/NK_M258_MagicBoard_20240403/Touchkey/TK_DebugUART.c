/**************************************************************************//**
 * @file     TK_DebugUART.c
 * @version  V1.00
 * @brief    UART debug & connect tool setting.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#include "NuMicro.h"
#include "TK_Demo.h"
void UART0_Init(void)
{
    /* Configure UART0 and set UART0 baud rate */
    UART_Open(UART0, 115200);
}