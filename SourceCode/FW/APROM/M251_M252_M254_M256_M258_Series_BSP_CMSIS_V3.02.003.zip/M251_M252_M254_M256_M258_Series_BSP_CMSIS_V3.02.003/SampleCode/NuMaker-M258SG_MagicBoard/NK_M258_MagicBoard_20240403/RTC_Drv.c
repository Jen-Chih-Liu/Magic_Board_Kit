/**************************************************************************//**
 * @file     LCD_NK.c
 * @version  V1.00
 * @brief    LCD Initial & Frame config.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "NU_M258KG.h"

volatile int32_t  g_i32Alarm  = FALSE;
S_RTC_TIME_DATA_T sCurTime;


#define T_60SEC     60 //60Sec
#define T_60MIN     60 //60MIN


void RTC_Update(void);
void RTC_IRQHandler(void)
{

    if ((RTC->INTEN & RTC_INTEN_ALMIEN_Msk) && (RTC->INTSTS & RTC_INTSTS_ALMIF_Msk))          /* alarm interrupt occurred */
    {
        g_i32Alarm = TRUE;

        RTC_CLEAR_ALARM_INT_FLAG();
    }

}
void RTC_from_LXT(void)
{
    /* Set X32_OUT(PF.4) and X32_IN(PF.5) to input mode to prevent leakage */
    PF->MODE &= ~(GPIO_MODE_MODE4_Msk | GPIO_MODE_MODE5_Msk);

    /* Enable external 32768Hz XTAL */
    CLK_EnableXtalRC(CLK_PWRCTL_LXTEN_Msk);

    /* Waiting for clock ready */
    CLK_WaitClockReady(CLK_STATUS_LXTSTB_Msk);

    /* Disable digital input path of analog pin X32_OUT to prevent leakage */
    GPIO_DISABLE_DIGITAL_PATH(PF, BIT4 | BIT5);
}
void RTC_Update(void)
{
    S_RTC_TIME_DATA_T sAlarmTime = {0};

    /* Get the current time */
    RTC_GetDateAndTime(&sAlarmTime);
    sAlarmTime.u32Minute = sAlarmTime.u32Minute + 1;

    if (sAlarmTime.u32Second >= T_60SEC)
    {
        sAlarmTime.u32Minute = sAlarmTime.u32Minute + (sAlarmTime.u32Second / T_60SEC);
        sAlarmTime.u32Second = sAlarmTime.u32Second % T_60SEC;
    }

    if (sAlarmTime.u32Minute >= T_60MIN)
    {
        sAlarmTime.u32Hour = sAlarmTime.u32Hour + (sAlarmTime.u32Minute / T_60MIN);
        sAlarmTime.u32Minute = sAlarmTime.u32Minute % T_60MIN;
    }

    if (sAlarmTime.u32Hour >= 24)
    {
        sAlarmTime.u32Hour -= 24;
    }

//    printf(" Alarm Time:%u/%02u/%02u %02u:%02u:%02u\n", sAlarmTime.u32Year, sAlarmTime.u32Month,
//
    /* Set the alarm time */
    RTC_SetAlarmDateAndTime(&sAlarmTime);
}

void RTC_Init(void)
{
    uint32_t    u32Addr, u32ByteCount;
    uint32_t    u32DataLength = 0;
    S_RTC_TIME_DATA_T sInitTime = {0};
		 if (g_u8IsWDTReset == 0)
		 {
				for (u32Addr = user_aprom_rtc_address; u32Addr < (user_aprom_rtc_address + 8); u32Addr += 4)
				{
						uint32_t    u32Data;
						uint8_t    u8DataTemp;

						u32Data = inpw(u32Addr);

						if (u32Data == 0xFFFFFFFF) //Content is empty and display default time on LCD
						{
								sInitTime.u32Year       = 2000 + 24;
								sInitTime.u32Month      = 4;
								sInitTime.u32Day        = 4;
								sInitTime.u32DayOfWeek  = RTC_THURSDAY;
								sInitTime.u32Hour       = 1;
								sInitTime.u32Minute     = 54;
								sInitTime.u32Second     = 0;
								break;
						}
						else
						{

								for (u32ByteCount = 0; u32ByteCount < 4; u32ByteCount++)
								{
										u8DataTemp = (uint8_t)(u32Data >> (8 * u32ByteCount));

										if (u32DataLength == 0)
										{
												sInitTime.u32Year       = 1900 + u8DataTemp;
										}
										else if (u32DataLength == 1)
										{
												sInitTime.u32Month       = u8DataTemp;
										}
										else if (u32DataLength == 2)
										{
												sInitTime.u32Day       = u8DataTemp;
										}
										else if (u32DataLength == 3)
										{
												sInitTime.u32DayOfWeek       = u8DataTemp;
										}
										else if (u32DataLength == 4)
										{
												sInitTime.u32Hour       = u8DataTemp;
										}
										else if (u32DataLength == 5)
										{
												sInitTime.u32Minute       = u8DataTemp;
										}
										else if (u32DataLength == 6)
										{
												sInitTime.u32Second       = u8DataTemp;
										}

										u32DataLength++;
								}
						}
				}
			
				/* Init RTC in the start of sample code */
				//  if (RTC->INIT != RTC_INIT_ACTIVE_Msk)
				{
						/* Open RTC */
						sInitTime.u32TimeScale  = RTC_CLOCK_24;
						RTC_Open(&sInitTime);
				}
		}
    g_i32Alarm = FALSE;

    /* Get the current time */
    RTC_GetDateAndTime(&sCurTime);
 //   printf("Current Time:%u/%02u/%02u %02u:%02u:%02u\n", sCurTime.u32Year, sCurTime.u32Month,
 //          sCurTime.u32Day, sCurTime.u32Hour, sCurTime.u32Minute, sCurTime.u32Second);		
    LCDLIB_SetSymbol(SYMBOL_COL, 1);
    LCDLIB_PrintNumber(ZONE_TIME_DIGIT, sCurTime.u32Hour * 100 + sCurTime.u32Minute);

    /* The alarm time setting */
    RTC_Update();
    RTC -> CAMSK = 0x3f;

    /* Clear interrupt status */
    RTC->INTSTS = RTC_INTSTS_ALMIF_Msk;

    /* Enable RTC Alarm Interrupt */
    RTC_EnableInt(RTC_INTEN_ALMIEN_Msk);

    NVIC_EnableIRQ(RTC_IRQn);

    /* Enable RTC wake-up from DPD */
    CLK_ENABLE_RTCWK();
}

