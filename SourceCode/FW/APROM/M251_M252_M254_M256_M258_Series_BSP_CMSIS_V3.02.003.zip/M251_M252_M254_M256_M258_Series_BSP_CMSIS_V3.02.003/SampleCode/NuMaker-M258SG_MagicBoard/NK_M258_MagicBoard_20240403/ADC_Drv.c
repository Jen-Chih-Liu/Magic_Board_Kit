//Tetris porting
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "NU_M258KG.h"

#define EADC_GET_VALID_VALUE(CONVERT_DATA)       ((CONVERT_DATA)&0xFFF)

/*---------------------------------------------------------------------------------------------------------*/
/* Define global variables and constants                                                                   */
/*---------------------------------------------------------------------------------------------------------*/
volatile uint32_t g_u32AdcIntFlag;
int32_t  i32ConversionData, i32BuiltInData;

/*---------------------------------------------------------------------------------------------------------*/
/* EADC interrupt handler                                                                                  */
/*---------------------------------------------------------------------------------------------------------*/
void EADC_INT0_IRQHandler(void)
{
    g_u32AdcIntFlag = 1;
    EADC_CLR_INT_FLAG(EADC, EADC_STATUS2_ADIF0_Msk);      /* Clear the A/D ADINT0 interrupt flag */
}

void ADC_Init(void)
{
    /* Set input mode as single-end and enable the A/D converter */
    EADC_Open(EADC, 0);

    /* Set sample module 16 external sampling time to 160 (M251 suggest total sample band-gap more than 10 us)*/
    EADC_SetExtendSampleTime(EADC, 16, 160);

    /* Clear the A/D ADINT0 interrupt flag for safe */
    EADC_CLR_INT_FLAG(EADC, EADC_STATUS2_ADIF0_Msk);

    /* Enable the sample module 16 interrupt.  */
    EADC_ENABLE_INT(EADC, BIT0);//Enable sample module A/D ADINT0 interrupt.
    EADC_ENABLE_SAMPLE_MODULE_INT(EADC, 0, BIT16);//Enable sample module 16 interrupt.
    NVIC_EnableIRQ(EADC_INT0_IRQn);
}

uint32_t ADC_Calculate_VBAT(void)
{

    EADC_Open(EADC, 0);

    /* Reset the ADC interrupt indicator and trigger sample module 16 to start A/D conversion */
    g_u32AdcIntFlag = 0;
    EADC_START_CONV(EADC, BIT16);

    /* Wait EADC conversion done */
    while (g_u32AdcIntFlag == 0);

    /* Get the conversion result of the sample module 16 */
    i32ConversionData = EADC_GET_CONV_DATA(EADC, 16);

    /* Enable FMC ISP function to read built-in band-gap A/D conversion result*/
    SYS_UnlockReg();
    FMC_Open();
    i32BuiltInData = FMC_ReadVBGCode();

    /* Use Conversion result of Band-gap to calculating AVdd */


    //    printf("      AVdd           i32BuiltInData                   \n");
    //    printf("   ---------- = -------------------------             \n");
    //    printf("      %d          i32ConversionData                   \n", (i32BuiltInData & 0x01000000) ? 3072 : 3300);
    //    printf("                                                      \n");
    //    printf("AVdd =  %d * i32BuiltInData / i32ConversionData     \n\n", (i32BuiltInData & 0x01000000) ? 3072 : 3300);


    //    printf("Built-in band-gap A/D conversion result: 0x%X (%d) \n", EADC_GET_VALID_VALUE(i32BuiltInData), EADC_GET_VALID_VALUE(i32BuiltInData));
    //    printf("Conversion result of Band-gap:           0x%X (%d) \n\n", i32ConversionData, i32ConversionData);



    /* Set input mode as single-end and enable the A/D converter */
    EADC_Close(EADC);
    //    FMC_Close();
    //    SYS_LockReg();

    if (i32BuiltInData & 0x01000000)
    {
        // printf("AVdd = 3072 * %d / %d = %d mV \n\n", EADC_GET_VALID_VALUE(i32BuiltInData), i32ConversionData, 3072 * EADC_GET_VALID_VALUE(i32BuiltInData) / i32ConversionData);
        return (3072 * EADC_GET_VALID_VALUE(i32BuiltInData) / i32ConversionData);
    }
    else
    {
        // printf("AVdd = 3300 * %d / %d = %d mV \n\n", EADC_GET_VALID_VALUE(i32BuiltInData), i32ConversionData, 3300 * EADC_GET_VALID_VALUE(i32BuiltInData) / i32ConversionData);
        return (3072 * EADC_GET_VALID_VALUE(i32BuiltInData) / i32ConversionData);

    }

}
