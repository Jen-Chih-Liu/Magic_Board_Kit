#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "NU_M258KG.h"

#define COLUMN 6UL
#define STRING_LENGTH 8UL
#define ROW 8UL
#define MAX_COLUMN 15UL
#define TOTAL_LENGTH 48UL//COLUMNxSTRING_LENGTH

extern uint8_t WordTable[101][6];

uint8_t StringData[50];
uint8_t TimeData[50];
uint8_t ImageData[50];

__attribute__((aligned(4))) volatile Marquee_Setting_T String_MarqueeSetting = {0, 0, 0, 0, StringData};
__attribute__((aligned(4))) volatile Marquee_Setting_T Time_MarqueeSetting = {0, 0, 0, 0, TimeData};
__attribute__((aligned(4))) volatile Marquee_Setting_T Image_MarqueeSetting = {0, 0, 0, 0, ImageData};

/* Get string content at user_aprom_data_address in APROM, If it is empty and display "Nuvoton" on LCD, displat Nuvoton on LCD */
void String_Marquee_Init(void)
{
    uint32_t    u32Addr, u32ByteCount;

    String_MarqueeSetting.DataLength = 0;

    for (u32Addr = user_aprom_data_address; u32Addr < (user_aprom_data_address + 48); u32Addr += 4)
    {
        uint32_t    u32Data;
        uint8_t    u8DataTemp;

        u32Data = inpw(u32Addr);

        if (u32Data == 0xFFFFFFFF) //It is empty and display "Nuvoton" on LCD
        {
            String_MarqueeSetting.DataBuf[0] = 'N';
            String_MarqueeSetting.DataBuf[1] = 'u';
            String_MarqueeSetting.DataBuf[2] = 'v';
            String_MarqueeSetting.DataBuf[3] = 'o';
            String_MarqueeSetting.DataBuf[4] = 't';
            String_MarqueeSetting.DataBuf[5] = 'o';
            String_MarqueeSetting.DataBuf[6] = 'n';
            String_MarqueeSetting.DataBuf[7] = ' ';
            String_MarqueeSetting.DataLength = 8;

            break;
        }
        else
        {
            for (u32ByteCount = 0; u32ByteCount < 4; u32ByteCount++)
            {
                u8DataTemp = (uint8_t)(u32Data >> (8 * u32ByteCount));

                if (u8DataTemp == 0)
                {
                    String_MarqueeSetting.DataBuf[String_MarqueeSetting.DataLength++] = ' ';
                    break;
                }

                String_MarqueeSetting.DataBuf[String_MarqueeSetting.DataLength++] = (uint8_t)u8DataTemp;
            }
        }

        if (u8DataTemp == 0)
            break;

    }
}
/* Get string content at user_aprom_image_address in APROM, If it is empty and display "Love.bmp" on LCD */
void Image_Marquee_Init(void)
{
    uint32_t    u32Addr, u32ByteCount;
    Image_MarqueeSetting.DataLength  = 0;
    //Image_MarqueeSetting.DataLength = 7;

    for (u32Addr = user_aprom_image_address; u32Addr < (user_aprom_image_address + 8); u32Addr += 4)
    {
        uint32_t    u32Data;
        uint8_t    u8DataTemp;

        u32Data = inpw(u32Addr);

        if (u32Data == 0xFFFFFFFF)
        {
            //"Love.bmp"
            Image_MarqueeSetting.DataBuf[0] = 0x38;
            Image_MarqueeSetting.DataBuf[1] = 0x7c;
            Image_MarqueeSetting.DataBuf[2] = 0x3e;
            Image_MarqueeSetting.DataBuf[3] = 0x1f;
            Image_MarqueeSetting.DataBuf[4] = 0x3e;
            Image_MarqueeSetting.DataBuf[5] = 0x7c;
            Image_MarqueeSetting.DataBuf[6] = 0x38;

        }
        else
        {
            for (u32ByteCount = 0; u32ByteCount < 4; u32ByteCount++)
            {
                u8DataTemp = (uint8_t)(u32Data >> (8 * u32ByteCount));
                //Image_MarqueeSetting.DataBuf[Image_MarqueeSetting.DataLength--] = (uint8_t)u8DataTemp;
                Image_MarqueeSetting.DataBuf[Image_MarqueeSetting.DataLength++] = (uint8_t)u8DataTemp;
            }
        }
    }

    Image_MarqueeSetting.DataLength = 14;
}
void Time_Marquee_Init(void)
{
    /* Get the current time */
    RTC_GetDateAndTime(&sCurTime);

    //2024/02/22 12:00:00
    Time_MarqueeSetting.DataLength = 0;

    sprintf((char *)Time_MarqueeSetting.DataBuf, "%d", sCurTime.u32Year);
    Time_MarqueeSetting.DataLength += 4;
    Time_MarqueeSetting.DataBuf[Time_MarqueeSetting.DataLength++] = '/';

    sprintf((char *)Time_MarqueeSetting.DataBuf + Time_MarqueeSetting.DataLength, "%02d", sCurTime.u32Month);
    Time_MarqueeSetting.DataLength += 2;

    Time_MarqueeSetting.DataBuf[Time_MarqueeSetting.DataLength++] = '/';

    sprintf((char *)Time_MarqueeSetting.DataBuf + Time_MarqueeSetting.DataLength, "%02d", sCurTime.u32Day);
    Time_MarqueeSetting.DataLength += 2;

    Time_MarqueeSetting.DataBuf[Time_MarqueeSetting.DataLength++] = ' ';
}
void Marquee_String_Routine(void)
{
    static uint32_t i;
    uint8_t   AsciiCode;

    for (i = 0; i < MAX_COLUMN; i++)//i = Dot Matrix Column
    {
        AsciiCode = String_MarqueeSetting.DataBuf[((String_MarqueeSetting.StartIdx / COLUMN) % String_MarqueeSetting.DataLength)] - 0x20; //Convert ascii to index
        LCDLIB_DotMatrixPutChar(ZONE_MAIN_DOT_MATRIX_DIGIT, i, WordTable[AsciiCode][String_MarqueeSetting.StartIdx % COLUMN]);

        String_MarqueeSetting.StartIdx = String_MarqueeSetting.StartIdx + 1;
        String_MarqueeSetting.StartIdx = String_MarqueeSetting.StartIdx % (String_MarqueeSetting.DataLength * COLUMN);
    }

    //Next frame start index
    String_MarqueeSetting.NextStartIdx = String_MarqueeSetting.NextStartIdx + 1;
    String_MarqueeSetting.NextStartIdx = String_MarqueeSetting.NextStartIdx % (String_MarqueeSetting.DataLength * COLUMN);
    String_MarqueeSetting.StartIdx = String_MarqueeSetting.NextStartIdx;
}
void Marquee_Time_Routine(void)
{
    static uint32_t i;
    uint8_t   AsciiCode;

    for (i = 0; i < MAX_COLUMN; i++)//i = Dot Matrix Column
    {
        AsciiCode = Time_MarqueeSetting.DataBuf[((Time_MarqueeSetting.StartIdx / COLUMN) % Time_MarqueeSetting.DataLength)] - 0x20; //Convert ascii to index
        LCDLIB_DotMatrixPutChar(ZONE_MAIN_DOT_MATRIX_DIGIT, i, WordTable[AsciiCode][Time_MarqueeSetting.StartIdx % COLUMN]);

        Time_MarqueeSetting.StartIdx = Time_MarqueeSetting.StartIdx + 1;
        Time_MarqueeSetting.StartIdx = Time_MarqueeSetting.StartIdx % (Time_MarqueeSetting.DataLength * COLUMN);
    }

    //Next frame start index
    Time_MarqueeSetting.NextStartIdx = Time_MarqueeSetting.NextStartIdx + 1;
    Time_MarqueeSetting.NextStartIdx = Time_MarqueeSetting.NextStartIdx % (Time_MarqueeSetting.DataLength * COLUMN);
    Time_MarqueeSetting.StartIdx = Time_MarqueeSetting.NextStartIdx;
}
void Marquee_Image_Routine(void)
{
    static uint32_t i;

    for (i = 0; i < MAX_COLUMN; i++)//i = Dot Matrix Column
    {
        LCDLIB_DotMatrixPutChar(ZONE_MAIN_DOT_MATRIX_DIGIT, i, Image_MarqueeSetting.DataBuf[Image_MarqueeSetting.StartIdx % 14]);

        Image_MarqueeSetting.StartIdx = Image_MarqueeSetting.StartIdx + 1;
        Image_MarqueeSetting.StartIdx = Image_MarqueeSetting.StartIdx % (Image_MarqueeSetting.DataLength * 14);
    }

    //Next frame start index
    Image_MarqueeSetting.NextStartIdx = Image_MarqueeSetting.NextStartIdx + 1;
    Image_MarqueeSetting.NextStartIdx = Image_MarqueeSetting.NextStartIdx % (Image_MarqueeSetting.DataLength * 14);
    Image_MarqueeSetting.StartIdx = Image_MarqueeSetting.NextStartIdx;
}


VoidFunc MarqueeFunc[3] =
{&Marquee_String_Routine, &Marquee_Time_Routine, &Marquee_Image_Routine};
