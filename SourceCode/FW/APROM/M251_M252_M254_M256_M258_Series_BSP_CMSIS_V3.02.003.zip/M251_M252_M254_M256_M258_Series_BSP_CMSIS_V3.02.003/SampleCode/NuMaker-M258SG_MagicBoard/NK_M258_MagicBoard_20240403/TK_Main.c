/**************************************************************************//**
 * @file     TK_Main.c
 * @version  V1.00
 * @brief    Magic board
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "tklib.h"
#include "lcdlib.h"
#include "NU_M258KG.h"

#define ADC_ON
#define RTC_ON
#define TK_ON
#define USB_ON
const uint32_t dummy_Data[1]__attribute__((section(".ARM.__at_0xFBF8"))) = {0xaabbccdd};


uint8_t   g_u8Scenario;
uint8_t   g_u8PageIdx;
uint8_t   g_u8LogPressFlag;


/* Touchkey Controller */
volatile int8_t i8KeyVal, i8KeyValPre;

Device_T Device_Config;

/* USB Controller*/
#define TRIM_INIT           (SYS_BASE + 0x118)
uint32_t u32TrimInit;
uint8_t   g_u8PlugIn, usb_detect_flag;
void USBD_IRQHandler(void);


/**
  *  Report touching or un-touching state depends on debounce parameter you set on calibration stage
  *  For example,
  *      TK_ScanKey() may report someone key pressed but its signal is less than threshold of the key.
  *      The root cause is the key still under de-bounce stage.
  */
unsigned char TK_RawDataView2(void)
{
    int8_t ai8Signal[TKLIB_TOL_NUM_KEY];
    static uint8_t  u8PressFlag = 0;

    if (u8EventKeyScan == 1)
    {
        u8EventKeyScan = 0;
        /**
          * TK_ScanKey() scan all enable key, slider and wheel channels.
          * i8Ret : Key/slider/wheel channel with max amplitude. -1: means no any key's amplitude over the key's threshold.
          * ai8Signal[]: The buffer size is equal to the ML56 TK channels. It reports the signal amplitude on this round
          */
        int8_t i8Ret = TK_ScanKey(&ai8Signal[0]);
        // printf("TK[%d]\r\n", i8Ret);

        if ((i8Ret == TK2) || (i8Ret == TK3) || (i8Ret == TK4))
        {
            //TK press
            if (i8KeyVal != i8Ret)
            {
                u8PressFlag = 1;
                i8KeyVal = i8Ret;
                return eMAIN_APP_TK_PRESS_STATE;
            }
            else
                return eMAIN_APP_TK_LONG_STATE;
        }
        else
        {
            //TK release
            i8KeyVal = i8Ret;

            if (u8PressFlag == 1)
            {
                u8PressFlag = 0;
                return eMAIN_APP_TK_RELEASE_STATE;
            }

        }
    }

    return eMAIN_APP_IDLE_STATE;
}
/*-----------------------------------------------------------------------------------------------------------*/
/*  Function for Check Reset Status                                                                          */
/*-----------------------------------------------------------------------------------------------------------*/
void CheckResetStatus(void)
{
    static uint32_t u32ResetCounter = 1UL;

    const uint32_t u32RestStatus = SYS_GetResetSrc();

    if (u32RestStatus & SYS_RSTSTS_VBATLVRF_Msk)
        printf("[%d] VBAT LVR Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_CPULKRF_Msk)
        printf("[%d] CPU Lockup Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_CPURF_Msk)
        printf("[%d] CPU Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_PMURF_Msk)
        printf("[%d] PMU Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_SYSRF_Msk)
        printf("[%d] System Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_BODRF_Msk)
        printf("[%d] BOD Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_LVRF_Msk)
        printf("[%d] LVR Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_WDTRF_Msk)
    {
        g_u8IsWDTReset = 1;
        printf("[%d] WDT Reset Flag\n", u32ResetCounter++);
    }

    if (u32RestStatus & SYS_RSTSTS_PINRF_Msk)
        printf("[%d] nRESET Pin Reset Flag\n", u32ResetCounter++);

    if (u32RestStatus & SYS_RSTSTS_PORF_Msk)
        printf("[%d] POR Reset Flag\n", u32ResetCounter++);

    /* Clear all reset flag */
    SYS->RSTSTS = SYS->RSTSTS;
}
/*-----------------------------------------------------------------------------------------------------------*/
/*  Function for Check Power Manager Status                                                                  */
/*-----------------------------------------------------------------------------------------------------------*/
void CheckPowerSource(void)
{
    const uint32_t u32RegRstsrc = CLK_GetPMUWKSrc();

    //printf("Power manager Power Manager Status 0x%x\n", u32RegRstsrc);

    if (u32RegRstsrc & CLK_PMUSTS_LVRWK_Msk)
        printf("Wake-up source is LVR.\n");

    if (u32RegRstsrc & CLK_PMUSTS_PINWK4_Msk)
        printf("Wake-up source is Wake-up Pin(GPF.6).\n");

    if (u32RegRstsrc & CLK_PMUSTS_PINWK3_Msk)
        printf("Wake-up source is Wake-up Pin(GPB.12).\n");

    if (u32RegRstsrc & CLK_PMUSTS_PINWK2_Msk)
        printf("Wake-up source is Wake-up Pin(GPB.2).\n");

    if (u32RegRstsrc & CLK_PMUSTS_PINWK1_Msk)
        printf("Wake-up source is Wake-up Pin(GPB.0).\n");

    if (u32RegRstsrc & CLK_PMUSTS_RTCWK_Msk)
        printf("Wake-up source is RTC.\n");

    if (u32RegRstsrc & CLK_PMUSTS_TMRWK_Msk)
        printf("Wake-up source is Wake-up Timer.\n");

    if (u32RegRstsrc & CLK_PMUSTS_PINWK0_Msk)
        printf("Wake-up source is Wake-up Pin(GPC.0).\n");
}
void SYS_Init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Enable LIRC clock (Internal RC 38.4Hz) */
    CLK_EnableXtalRC(CLK_PWRCTL_LIRCEN_Msk);
    /* Wait for LIRC clock ready */
    CLK_WaitClockReady(CLK_STATUS_LIRCSTB_Msk);

    /* Enable HIRC clock (Internal RC 48MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);
    /* Wait for HIRC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Select HCLK clock source as HIRC and and HCLK source divider as 1 */
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HIRC, CLK_CLKDIV0_HCLK(1));
    CLK_DisableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Set both PCLK0 and PCLK1 as HCLK/2 */
    CLK->PCLKDIV = CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2;
#ifdef RTC_ON
    RTC_from_LXT();
    CLK_EnableModuleClock(RTC_MODULE);
#endif

#ifdef TK_ON
    /* Enable TIMER2 peripheral clock */
    CLK_EnableModuleClock(TMR2_MODULE);
    /* Enable TK peripheral clock */
    CLK_EnableModuleClock(TK_MODULE);
#endif

    CLK_EnableModuleClock(LCD_MODULE);
    CLK_SetModuleClock(LCD_MODULE, CLK_CLKSEL2_LCDSEL_LIRC, 0);

    CLK_EnableModuleClock(GPA_MODULE);
    CLK_EnableModuleClock(GPB_MODULE);
    CLK_EnableModuleClock(GPC_MODULE);
    CLK_EnableModuleClock(GPD_MODULE);
    CLK_EnableModuleClock(GPE_MODULE);
    CLK_EnableModuleClock(GPF_MODULE);
    CLK_EnableModuleClock(UART0_MODULE);
#if 1
#ifdef USB_ON
    /* USBD recive string */
    CLK_EnableModuleClock(USBD_MODULE);
    CLK_EnableModuleClock(EXST_MODULE);
#endif
    /* Select Timer0 & WDT clock source from LIRC */
    CLK_EnableModuleClock(TMR0_MODULE);
    CLK_SetModuleClock(TMR0_MODULE, CLK_CLKSEL1_TMR0SEL_LIRC, 0);
    CLK_EnableModuleClock(WDT_MODULE);
    CLK_SetModuleClock(WDT_MODULE, CLK_CLKSEL1_WDTSEL_LIRC, 0);
#ifdef ADC_ON
    /* Enable EADC module clock */
    CLK_EnableModuleClock(EADC_MODULE);
    CLK_SetModuleClock(EADC_MODULE, 0, CLK_CLKDIV0_EADC(3));
#endif

#endif

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init I/O Multi-function                                                                                 */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Configure unused GPIO pins as Quasi-bidirectional Mode*/
    GPIO_SetMode(PA, BIT1 | BIT5 | BIT8 | BIT9 | BIT10 | BIT11, GPIO_MODE_QUASI);
    GPIO_SetMode(PF, BIT2 | BIT3, GPIO_MODE_QUASI);

    /* Set GPF multi-function pins for UART0 RXD and TXD */
    SYS->GPF_MFPL = (SYS->GPF_MFPL & ~SYS_GPF_MFPL_PF2MFP_Msk) | SYS_GPF_MFPL_PF2MFP_UART0_RXD;
    SYS->GPF_MFPL = (SYS->GPF_MFPL & ~SYS_GPF_MFPL_PF3MFP_Msk) | SYS_GPF_MFPL_PF3MFP_UART0_TXD;

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    SystemCoreClockUpdate();
}

/*---------------------------------------------------------------------------------------------------------*/
/*  Function for System Entry to Power Down Mode                                                           */
/*---------------------------------------------------------------------------------------------------------*/
void PowerDownFunction(void)
{
#if 1
    CLK_SetModuleClock(TMR2_MODULE, CLK_CLKSEL1_TMR2SEL_LIRC, 0);
    TIMER_Open(TIMER2, TIMER_PERIODIC_MODE, 50);
    NVIC_DisableIRQ(TMR2_IRQn);
    TIMER_ClearIntFlag(TIMER2);
    TIMER2->INTSTS = TIMER2->INTSTS;

    TK_ConfigPowerDown(-1);
    TIMER2->TRGCTL |= TIMER_TRGCTL_TRGTK_Msk;
    TIMER_Start(TIMER2);
    CLK_SysTickDelay(10);

    // while ((UART0->FIFOSTS & UART_FIFOSTS_TXEMPTY_Msk) == 0) {}

    /* Unlock protected registers for Power-down and wake-up setting */
    SYS_UnlockReg();
    CLK_SetPowerDownMode(CLK_PMUCTL_PDMSEL_PD);
    CLK_SysTickDelay(10);
    CLK_PowerDown();
    CheckPowerSource();

    // SYS_LockReg();
    /* Disable TMRTRG */
    TIMER2->TRGCTL &= ~TIMER_TRGCTL_TRGTK_Msk;
    FMC_ENABLE_ISP();
    CLK_SetModuleClock(TMR2_MODULE, CLK_CLKSEL1_TMR2SEL_PCLK1, 0);
    TIMER_ClearIntFlag(TIMER2);

    /* Init systick 20ms/tick */
    Init_SysTick();
    /* Install Tick Event Handler */
    TickCallbackFun();

#endif
}

void USBD_Init(void)
{
    /* Open USB controller */
    USBD_Open(&gsInfo, HID_ClassRequest, NULL);

    /*Init Endpoint configuration for HID */
    HID_Init();

    /* Start USB device */
    USBD_Start();

    /* Backup default trim value */
    u32TrimInit = M32(TRIM_INIT);

    /* Clear SOF */
    USBD_CLR_INT_FLAG(USBD_INTSTS_SOFIF_Msk);

    /* Enable Wake-up Source */
    USBD_ENABLE_INT(USBD_INTEN_WKEN_Msk);
}

int32_t main(void)
{
    uint32_t u32ChanelMsk;
    uint8_t u8MainState = eMAIN_APP_IDLE_STATE;

    uint32_t u32VbatVoltage = 0;
    uint8_t u8Toggle = 0;
    uint8_t dummyread = dummy_Data[0];

    SYS_Init();

#if 1
    SYS_DISABLE_BOD();          // disable BOD
    SYS_DISABLE_POR();          // disable POR
    SYS->PORCTL0 = 0x5AA5;  //disable digital POR
    SYS->PORCTL1 = 0x5AA5;  //disable analog POR
#endif

#ifdef TK_ON
    int8_t i8Ret = TK_LoadPara(&u32ChanelMsk);

    if (i8Ret < 0)
    {
        /* DBG_PRINTF("Please run target TK_Application first to calibrate touchkey\n"); */
        while (1);
    }

    /* Init TK Controller */
    TK_Init();

    /* Initialize Multiple Function Pins for TK */
    SetTkMultiFun(u32ChanelMsk);

    /* Init systick 20ms/tick */
    Init_SysTick();

    /* Install Tick Event Handler */
    TickCallbackFun();
#endif

    UART0_Init();
    //printf("Magic Board\r\n");
    /* Get power manager wake up source */
    CheckPowerSource();
    /* Get Reset Status */
    CheckResetStatus();

#ifdef RTC_ON
	RTC->LXTCTL |= BIT8;    //IOCTLSEL
	RTC->GPIOCTL0 = 0x000D0D0D;
	RTC_Init();//Update LCD Screen
  g_u8IsWDTReset = 0;
#endif


#ifdef ADC_ON
    /* Set input mode as single-end and enable the A/D converter */
    ADC_Init();
    u32VbatVoltage = ADC_Calculate_VBAT();
#endif

    /* Initialize Timer0 to wakeup system */
    TMR0_Init();

    /* Marquee_Init */
    String_Marquee_Init();
    Image_Marquee_Init();
    Time_Marquee_Init();

    g_u8Scenario = MarqueeScenario;
    Device_Config.IsPowerON = PWR_ON;
    Device_Config.IsDebugMode = USB_MODE;

    /* Initialize LCD pin */
    LCD_Init_Setting();
#ifdef USB_ON
    USBD_Init();
#endif

RESTART:

#ifdef ADC_ON
    LCD_Battery_State(u32VbatVoltage);
#endif
    LCD_PowerOn();
    usb_detect_flag  = 0;
    WDT_CLEAR_RESET_FLAG();
    WDT_Init();
    while (1)
    {

        if (g_u8IsWDTTimeoutINT == 1)
        {
            g_u8IsWDTTimeoutINT = 0;
            g_u32WDTINTCounts = 0;
            //   printf(" WDT interrupt\n\n");

        }

#if 1

        /*---------------------------------------------------------------------------------------------------------*/
        /* IDLE routine                                                                                                */
        /*---------------------------------------------------------------------------------------------------------*/
        if (g_u8Scenario == MarqueeScenario)
        {
            if (u8EventTMR0Timeout == 1)
            {
                u8EventTMR0Timeout = 0;

                if (Device_Config.IsPowerON == PWR_ON)
                {
                    (*MarqueeFunc[g_u8PageIdx])();//
                }

                /*--------------------------------------------*/
                /* RTC COL Toggle Event                       */
                /*--------------------------------------------*/
                u8Toggle++;

                if (u8Toggle & 0x01)
                    LCDLIB_SetSymbol(SYMBOL_COL, 1);
                else
                    LCDLIB_SetSymbol(SYMBOL_COL, 0);

                if (u8MainState == eMAIN_APP_IDLE_STATE)
                {
                    PowerDownFunction();
                }
            }
        }
        else
        {
            /*--------------------------------------------*/
            /* RTC COL Toggle Event                       */
            /*--------------------------------------------*/
            if (u8EventTMR0Timeout == 1)
            {
                u8EventTMR0Timeout = 0;
                u8Toggle++;

                if (u8Toggle & 0x01)
                    LCDLIB_SetSymbol(SYMBOL_COL, 1);
                else
                    LCDLIB_SetSymbol(SYMBOL_COL, 0);
            }

            //   SYS_UnlockReg();
            CLK_Idle();
            //  SYS_LockReg();

            if (Device_Config.IsPowerON == PWR_ON)
            {
                Tetris_loop();
            }
        }

#ifdef RTC_ON

        if (g_i32Alarm == TRUE)//Update clock and battery voltage every 1 minute
        {
            g_i32Alarm = FALSE;

            /* Get the current time and update marquee data buffer at the same time */
            Time_Marquee_Init();
            LCDLIB_PrintNumber(ZONE_TIME_DIGIT, sCurTime.u32Hour * 100 + sCurTime.u32Minute);
//            printf(" Current Time:%u/%02u/%02u %02u:%02u:%02u\n", sCurTime.u32Year, sCurTime.u32Month,
//                   sCurTime.u32Day, sCurTime.u32Hour, sCurTime.u32Minute, sCurTime.u32Second);
            /* Update the alarm time */
            RTC_Update();


            if (g_u8Scenario == MarqueeScenario)
            {
#ifdef ADC_ON
                u32VbatVoltage = ADC_Calculate_VBAT();
                //printf("VBAT = %d\r\n", u32VbatVoltage);
                LCD_Battery_State(u32VbatVoltage);
#endif
            }
        }

#endif

        //Untouched timeout, From Tetris process switch to Marquee process
        if (g_u8Scenario == TetrisScenario)
        {
            if (u8EventUntouched == 1)
            {
                u8EventUntouched = 0;
                g_u8Scenario = MarqueeScenario;

                Tetris_ClearAllBlock();
                LCD_Marquee_Frame();
            }
        }

#endif
        /*---------------------------------------------------------------------------------------------------------*/
        /* End of IDLE routine                                                                                         */
        /*---------------------------------------------------------------------------------------------------------*/
#ifdef TK_ON
        /*---------------------------------------------------------------------------------------------------------*/
        /* Touch key routine                                                                                       */
        /*---------------------------------------------------------------------------------------------------------*/
        u8MainState = TK_RawDataView2();

        /* LCD Display base on TK */
        switch (u8MainState)
        {
            case eMAIN_APP_IDLE_STATE:
                break;

            case eMAIN_APP_TK_PRESS_STATE:

                i8KeyValPre = i8KeyVal;
                u32EventTMR0Count = 0;
                u8EventKeyLongPress = 0;
                break;

            case eMAIN_APP_TK_RELEASE_STATE://Short press event
                if (u8EventKeyLongPress == 0)
                {
                    //  printf("Short[%d]\r\n", i8KeyValPre);
                    (*TKFunc[i8KeyValPre])();
                    u8MainState = eMAIN_APP_IDLE_STATE;

                    if (g_u8Scenario == MarqueeScenario)
                    {
                        PowerDownFunction();
                    }
                }

                break;

            case eMAIN_APP_TK_LONG_STATE:

                //   printf("[%d][%d]\r\n", u8EventKeyLongPress, u32EventTMR0Count);

                if ((u8EventKeyLongPress == 0) && (u32EventTMR0Count >= 10))
                {
                    //Long press event 500ms*6 = 3000ms
                    {
                        u32EventTMR0Count = 0;
                        u8EventKeyLongPress = 1;
                        (*TKFunc[i8KeyValPre + 3])();
                        //  printf("Long[%d]\r\n", i8KeyValPre);
                        u8MainState = eMAIN_APP_IDLE_STATE;

                        if (g_u8Scenario == MarqueeScenario)
                        {
                            PowerDownFunction();
                        }
                    }
                }

                break;

            default:
                break;
        }

        /*---------------------------------------------------------------------------------------------------------*/
        /* End of Touch key routine                                                                                */
        /*---------------------------------------------------------------------------------------------------------*/
#endif

#ifdef USB_ON

        if (Device_Config.IsDebugMode == USB_MODE)
        {
            /*---------------------------------------------------------------------------------------------------------*/
            /* Check VBUS is plug in                                                                                   */
            /*---------------------------------------------------------------------------------------------------------*/
            CLK->APBCLK0 |= CLK_APBCLK0_USBDCKEN_Msk;

            if (USBD_IS_ATTACHED())
            {
                usb_detect_flag++;
            }
            else
            {
                usb_detect_flag = 0;
            }

            if (USBD_IS_ATTACHED() && usb_detect_flag > 2)
            {
                WDT_Close();
                USBD_Init();

                //check vbus is plug in
                while (USBD_IS_ATTACHED())
                {
                    g_u8PlugIn = 1;

                    if ((CLK_GetHCLKFreq() / 4000000) <= 1)
                    {
                        /* Enable HIRC clock (Internal RC 48MHz) */
                        CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);

                        /* Wait for HIRC clock ready */
                        CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

                        /* Select HCLK clock source as HIRC and and HCLK source divider as 1 */
                        CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HIRC, CLK_CLKDIV0_HCLK(1));
                    }

                    FMC->ISPCTL |= FMC_ISPCTL_ISPEN_Msk;
                    FMC->ISPCTL |= FMC_ISPCTL_APUEN_Msk;

                    /* Start USB trim function if it is not enabled. */
                    if ((SYS->HIRCTRIMCTL & SYS_HIRCTRIMCTL_FREQSEL_Msk) != 0x1)
                    {
                        /* Start USB trim only when USB signal arrived */
                        if (USBD->INTSTS & USBD_INTSTS_SOFIF_Msk)
                        {
                            /* Clear SOF */
                            USBD_CLR_INT_FLAG(USBD_INTSTS_SOFIF_Msk);

                            /*
                                USB clock trim function:
                                HIRC Trimming with boundary function enhances robustility
                                and keeps HIRC in right frequency while receiving unstable USB signal
                            */
                            SYS->HIRCTRIMCTL = (0x1 << SYS_HIRCTRIMCTL_REFCKSEL_Pos)
                                               | (0x1 << SYS_HIRCTRIMCTL_FREQSEL_Pos)
                                               | (0x0 << SYS_HIRCTRIMCTL_LOOPSEL_Pos)
                                               | (0x1 << SYS_HIRCTRIMCTL_BOUNDEN_Pos)
                                               | (10  << SYS_HIRCTRIMCTL_BOUNDARY_Pos);
                        }
                    }

                    /* Disable USB Trim when any error found */
                    if (SYS->HIRCTRIMSTS & (SYS_HIRCTRIMSTS_CLKERIF_Msk | SYS_HIRCTRIMSTS_TFAILIF_Msk))
                    {
                        /* Init TRIM */
                        M32(TRIM_INIT) = u32TrimInit;

                        /* Disable USB clock trim function */
                        SYS->HIRCTRIMCTL = 0;

                        /* Clear trim error flags */
                        SYS->HIRCTRIMSTS = SYS_HIRCTRIMSTS_CLKERIF_Msk | SYS_HIRCTRIMSTS_TFAILIF_Msk;

                        /* Clear SOF */
                        USBD_CLR_INT_FLAG(USBD_INTSTS_SOFIF_Msk);
                    }

                    // polling USBD interrupt flag
                    USBD_IRQHandler();

                    if (bUsbDataReady == TRUE)
                    {
                        ParseCmd((uint8_t *)usb_rcvbuf, 64);
                        EP2_Handler();
                        bUsbDataReady = FALSE;
                    }

                    if (bUsbStringDataReady == TRUE)
                    {
                        bUsbStringDataReady = FALSE;
                        String_Marquee_Init();
                    }

                    if (bUsbTimeDataReady == TRUE)
                    {
                        bUsbTimeDataReady = FALSE;
                        RTC_Init();
                        Time_Marquee_Init();
                    }

                    if (bUsbImageDataReady == TRUE)
                    {
                        bUsbImageDataReady = FALSE;
                        Image_Marquee_Init();
                    }
                }

            }

            CLK->APBCLK0 &= ~CLK_APBCLK0_USBDCKEN_Msk;

            if (g_u8PlugIn)
            {
                g_u8PlugIn = 0;
                /* Select HCLK clock source as MIRC and and HCLK source divider as 1 */
                CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_MIRC, CLK_CLKDIV0_HCLK(1));
                /* Enable MIRC clock (Internal RC 4MHz) */
                CLK_DisableXtalRC(CLK_PWRCTL_HIRCEN_Msk);
                goto RESTART;
            }
        }

        /*---------------------------------------------------------------------------------------------------------*/
        /* End of USB detect routine                                                                               */
        /*---------------------------------------------------------------------------------------------------------*/
#endif

    }
}

