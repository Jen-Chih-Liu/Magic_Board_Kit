//Tetris porting
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "NU_M258KG.h"

//memory assign
#define bound 1       //the bound is memory set
#define ROW 15+bound  //The number of rows in the game area 
#define COL 10  //The number of columns in the game area

//goble variable
unsigned char ch;
unsigned int max, grade;
unsigned char u8GameOverFlag = 0;

struct Face
{
    unsigned char data[ROW][COL];   //Used to mark whether there is a block at the specified position (1 means yes, 0 means no)
    //int color[ROW][COL];          //Used to record the color code of the block at the specified position
} volatile face;

struct Block
{
    unsigned char space[4][4];
} volatile block[7][4]; //Used to store information of 4 forms of each of 7 basic shape blocks, 28 types in total


void Tetris_init(void);


//Initialization interface
void InitInterface(void)
{
    for (int i = 0; i < ROW ; i++)
    {
        for (int j = 0; j <  COL + 10; j++)
        {
            if (j == 0 || j == COL - 1 || j == COL + 9)
            {
                face.data[i][j] = 1; //Mark this position with a square
                //printf("�");
            }
            else if (i == ROW - 1)
            {
                face.data[i][j] = 1; //Mark this position with a square
                //printf("�");
            }
            else
                face.data[i][j] = 0; //Mark that there is no block at this location
        }
    }

    for (int i = COL; i < COL + 10; i++)
    {
        face.data[8][i] = 1; //Mark this position with a square
        //printf("�");
    }

    for (int i = 1; i < COL - 1; i++)
    {
        face.data[9][i] = 0;
    }
}

//Initialize block information
void InitBlockInfo(void)
{
    //"T" shape
    for (int i = 0; i <= 2; i++)
        block[0][0].space[1][i] = 1;

    block[0][0].space[2][1] = 1;

    //"L" shape
    for (int i = 1; i <= 3; i++)
        block[1][0].space[i][1] = 1;

    block[1][0].space[3][2] = 1;

    //"J" shape
    for (int i = 1; i <= 3; i++)
        block[2][0].space[i][2] = 1;

    block[2][0].space[3][1] = 1;

    for (int i = 0; i <= 1; i++)
    {
        //"Z" shape
        block[3][0].space[1][i] = 1;
        block[3][0].space[2][i + 1] = 1;
        //"S" shape
        block[4][0].space[1][i + 1] = 1;
        block[4][0].space[2][i] = 1;
        //"O" shape
        block[5][0].space[1][i + 1] = 1;
        block[5][0].space[2][i + 1] = 1;
    }

    //"I" shape
    for (int i = 0; i <= 3; i++)
        block[6][0].space[i][1] = 1;

    int temp[4][4];

    for (int shape = 0; shape < 7; shape++)  //7 shapes
    {
        for (int form = 0; form < 3; form++)  //4 forms (there is already one, and 3 more forms need to be added here)
        {
            //Get the form form
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    temp[i][j] = block[shape][form].space[i][j];
                }
            }

            //Rotate the form form clockwise to obtain the form+1 form
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    block[shape][form + 1].space[i][j] = temp[3 - j][i];
                }
            }
        }
    }

}
#define On 1
//Draw the square
void DrawBlock(int shape, int form, int x, int y)
{
    if (x > COL)
    {
        if (block[shape][form].space[0][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A1, On);
        }

        if (block[shape][form].space[0][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A2, On);
        }

        if (block[shape][form].space[0][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A3, On);
        }

        if (block[shape][form].space[0][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A4, On);
        }

        if (block[shape][form].space[1][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A5, On);
        }

        if (block[shape][form].space[1][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A6, On);
        }

        if (block[shape][form].space[1][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A7, On);
        }

        if (block[shape][form].space[1][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A8, On);
        }

        if (block[shape][form].space[2][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A9, On);
        }

        if (block[shape][form].space[2][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A10,    On);
        }

        if (block[shape][form].space[2][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A11,    On);
        }

        if (block[shape][form].space[2][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A12,    On);
        }

        if (block[shape][form].space[3][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A13,    On);
        }

        if (block[shape][form].space[3][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A14,    On);
        }

        if (block[shape][form].space[3][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A15,    On);
        }

        if (block[shape][form].space[3][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A16,    On);
        }
    }

    if ((x <= COL))
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (block[shape][form].space[i][j] == 1)  //If there is a block at this position
                {
                    //printf("�"); //output square
                    LCDLIB_SetSymbol_Position((x - 1) + j, y + i, 1);
                }
            }
        }
    }
}
#define Off 0
//space coverage
void DrawSpace(int shape, int form, int x, int y)
{
    if (x > COL)
    {
        if (block[shape][form].space[0][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A1, Off);
        }

        if (block[shape][form].space[0][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A2, Off);
        }

        if (block[shape][form].space[0][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A3, Off);
        }

        if (block[shape][form].space[0][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A4, Off);
        }

        if (block[shape][form].space[1][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A5, Off);
        }

        if (block[shape][form].space[1][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A6, Off);
        }

        if (block[shape][form].space[1][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A7, Off);
        }

        if (block[shape][form].space[1][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A8, Off);
        }

        if (block[shape][form].space[2][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A9, Off);
        }

        if (block[shape][form].space[2][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A10,    Off);
        }

        if (block[shape][form].space[2][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A11,    Off);
        }

        if (block[shape][form].space[2][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A12,    Off);
        }

        if (block[shape][form].space[3][0] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A13,    Off);
        }

        if (block[shape][form].space[3][1] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A14,    Off);
        }

        if (block[shape][form].space[3][2] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A15,    Off);
        }

        if (block[shape][form].space[3][3] == 1)
        {
            LCDLIB_SetSymbol(SYMBOL_A16,    Off);
        }
    }

    if ((x <= COL))
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (block[shape][form].space[i][j] == 1)  //If there is a block at this position
                {
                    //printf(" "); //Print space coverage (two spaces)
                    LCDLIB_SetSymbol_Position((x - 1) + j, y + i, 0);
                }
            }
        }
    }
}

//Legality judgment
int IsLegal(int shape, int form, int x, int y)
{
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            //If there is already a block at the location where the block falls, it is illegal.
            if ((block[shape][form].space[i][j] == 1) && (face.data[y + i][x + j] == 1))
                return 0; //Illegal
        }
    }

    return 1; //legal
}

//Judge score and end
int JudeFunc()
{
    //Determine whether to score
    for (int i = ROW - 2; i >= 0; i--)
    {
        int sum = 0; //Record the number of blocks in the i-th row

        for (int j = 1; j < COL - 1; j++)
        {
            sum += face.data[i][j]; //Count the number of blocks in row i
        }

        if (sum == 0) //There are no blocks in this row, so there is no need to judge the level above it (no need to continue to judge whether to score)
            break; //break out of the loop

        if (sum == COL - 2)  //This row is full of squares and can score points
        {
            grade += 10; //Add 10 points to a full line

            //printf("Current score: %d", grade); //Update the current score
            for (int j = 1; j < COL - 1; j++)  //Clear the square information of the scoring row
            {
                face.data[i][j] = 0; //This position will be cleared after scoring and marked as no square
                //printf(" "); //Print space coverage (two spaces)
                LCDLIB_SetSymbol_Position((j - 1), i, 0);
            }

            //Move the entire row above the cleared row down one space
            for (int m = i; m > 1; m--)
            {
                sum = 0; //Record the number of blocks in the previous line

                for (int n = 1; n < COL - 1; n++)
                {
                    sum += face.data[m - 1][n]; //Count the number of blocks in the previous row
                    face.data[m][n] = face.data[m - 1][n]; //Move the logo of the previous row of blocks to the next row

                    //face.color[m][n] = face.color[m - 1][n]; //Move the color number of the previous row of squares to the next row
                    if (face.data[m][n] == 1)  //The box moved down from the previous line is printed.
                    {
                        //printf("�"); //Print square
                        LCDLIB_SetSymbol_Position(n - 1, m, 1);
                    }
                    else     //The previous line moved down is a space, print the space
                    {
                        LCDLIB_SetSymbol_Position(n - 1, m, 0);
                        //printf(" "); //Print spaces (two spaces)
                    }
                }

                if (sum == 0) //The previous line moved down are all spaces, there is no need to move the upper block down (the movement ends)
                    return 1; //Return 1, indicating that the function still needs to be called for judgment (there may be full rows moved)
            }
        }
    }

    //Determine whether the game is over
    for (int j = 1; j < COL - 1; j++)
    {
        if (face.data[1][j] == 1)  //There are blocks on the top level (line 1 is the top level, not line 0)
        {
            if (grade > max)
            {
                //printf("Congratulations on breaking the highest record, the highest record is updated to %d", grade);
                //WriteGrade();
            }
            else if (grade == max)
            {
                //printf("Stay with the highest record, work hard to achieve greater results", grade);
            }
            else
            {
                //printf("Please keep working hard, the difference between the current record and the highest record is %d", max - grade);
            }

            u8GameOverFlag = 1;//GAME OVER

            return 0;
            //printf("GAME OVER");

        }
    }

    return 0; //The judgment is over, there is no need to call this function for judgment again
}

int shape, form ;
unsigned char u8Process = 0;
int nextShape, nextForm ;
int t, x = 4, y = 0;
//Game main logic function
void Tetris_loop(void)
{
    LCDLIB_PrintNumber(ZONE_SCORE_DIGIT, grade);

    switch (u8Process)
    {
        case 0://Initialize parameter
            t = 30;
            nextShape = rand() % 7;
            nextForm = rand() % 4; //Randomly obtain the shape and form of the next block
            x = 4, y = 0; //The horizontal and vertical coordinates of the initial falling position of the block
            DrawBlock(nextShape, nextForm, COL + 3, 3); //Display the next block in the upper right corner

            u8Process = 1;
            break;

        case 1://Display
            DrawBlock(shape, form, x, y); //Display the block at the initial falling position

            if (t == 0)
            {
                t = 30; //The smaller the t here, the faster the block will fall (the difficulty of the game can be set based on this)
            }

            while (--t)
            {
                //If the keyboard is tapped, exit the loop
                break;
            }

            if (t == 0)  //The keyboard has not been tapped
            {
                if (IsLegal(shape, form, x, y + 1) == 0)  //It is illegal for the block to fall further (it has reached the bottom)
                {
                    //Enter the information of the current block into the face
                    //face: Record whether there is a square in each position of the interface. If there is a square, record the color of the square in that position.
                    for (int i = 0; i < 4; i++)
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            if (block[shape][form].space[i][j] == 1)
                            {
                                face.data[y + i][x + j] = 1; //Mark this position as having a square
                            }
                        }
                    }

                    while (JudeFunc()); //Determine whether the falling block scores points and whether the game is over

                    if (u8GameOverFlag == 1)
                    {
                        Tetris_init();
                        u8GameOverFlag = 0;
                        break;
                    }

                    shape = nextShape, form = nextForm; //Get information about the next block
                    DrawSpace(nextShape, nextForm, COL + 3, 3); //Overwrite the square information in the upper right corner with spaces
                    u8Process = 0;
                    break; //Jump out of the current infinite loop and prepare for the next block to fall.
                }
                else     //not to the bottom
                {
                    DrawSpace(shape, form, x, y); //Use space to cover the current square position
                    y++; //The vertical coordinate increases automatically (the next time the box is displayed, it is equivalent to falling one square)
                }
            }

            break;
    }//switch-case
}
void Tetris_TK_Event(int8_t channel)
{
    //The keyboard was tapped
    {
        ch = channel;

        switch (ch)
        {

            case TK4: //Direction key: left
                if (IsLegal(shape, form, x - 1, y) == 1)  //Determine whether the block is legal after moving one position to the left
                {
                    //The following operations can only be performed after the block is moved to the left and is legal.
                    DrawSpace(shape, form, x, y); //Use space to cover the current square position
                    x--; //The abscissa decreases (the next time the box is displayed, it is equivalent to moving one space to the left)
                }

                ch = 0;
                break;

            case TK2: //Direction key: right
                if (IsLegal(shape, form, x + 1, y) == 1)  //Determine whether the block is legal after moving one position to the right
                {
                    //The following operations can only be performed after the block is moved to the right and is legal.
                    DrawSpace(shape, form, x, y); //Use space to cover the current square position
                    x++; //The abscissa increases automatically (the next time the box is displayed, it is equivalent to moving one space to the right)
                }

                ch = 0;
                break;

            case TK3: //space bar
                if (IsLegal(shape, (form + 1) % 4, x, y + 1) == 1)  //Determine whether the square is legal after rotation
                {
                    //The following operations can only be performed after the block is rotated and is legal.
                    DrawSpace(shape, form, x, y); //Use space to cover the current square position
                    y++; //The vertical coordinate increases automatically (you can�t rotate in place)
                    form = (form + 1) % 4; //The shape of the block increases automatically (the next time the block is displayed, it is equivalent to rotating)
                }


                ch = 0;
                break;

            default:
                ch = 0;
                break;
        }
    }
}



void Tetris_ClearAllBlock(void)
{
    unsigned char i;

    for (i = 0; i < 15; i++)
    {
        LCDLIB_DotMatrixPutChar(ZONE_MAIN_DOT_MATRIX_DIGIT, i, 0x00);
    }

    LCDLIB_SetSymbol(SYMBOL_A1, 0);
    LCDLIB_SetSymbol(SYMBOL_A2, 0);
    LCDLIB_SetSymbol(SYMBOL_A3, 0);
    LCDLIB_SetSymbol(SYMBOL_A4, 0);
    LCDLIB_SetSymbol(SYMBOL_A5, 0);
    LCDLIB_SetSymbol(SYMBOL_A6, 0);
    LCDLIB_SetSymbol(SYMBOL_A7, 0);
    LCDLIB_SetSymbol(SYMBOL_A8, 0);
    LCDLIB_SetSymbol(SYMBOL_A9, 0);
    LCDLIB_SetSymbol(SYMBOL_A10, 0);
    LCDLIB_SetSymbol(SYMBOL_A11, 0);
    LCDLIB_SetSymbol(SYMBOL_A12, 0);
    LCDLIB_SetSymbol(SYMBOL_A13, 0);
    LCDLIB_SetSymbol(SYMBOL_A14, 0);
    LCDLIB_SetSymbol(SYMBOL_A15, 0);
    LCDLIB_SetSymbol(SYMBOL_A16, 0);
}

void Tetris_init(void)
{
    max = 0;
    grade = 0;
    u8Process = 0;

    Tetris_ClearAllBlock();
    InitInterface();
    InitBlockInfo();

    shape = rand() % 7;
    form = rand() % 4;// Randomly obtain the shape and form of the block
}