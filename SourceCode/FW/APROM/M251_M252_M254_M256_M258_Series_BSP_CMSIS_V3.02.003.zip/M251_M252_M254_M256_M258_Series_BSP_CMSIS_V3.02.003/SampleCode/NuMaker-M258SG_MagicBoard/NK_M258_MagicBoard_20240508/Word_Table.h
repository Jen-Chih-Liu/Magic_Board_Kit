/**************************************************************************//**
 * @file     Word_Table.h
 * @version  V1.00
 * @brief    Word Table
 *
 * @copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __Word_Table_H__
#define __Word_Table_H__
#include "NuMicro.h"


#endif  /* __Word_Table_H__ */

/*** (C) COPYRIGHT 2023 Nuvoton Technology Corp. ***/
