/**************************************************************************//**
 * @file     lcdlib.c
 * @version  V3.00
 * @brief    RHE6616TP01(8-COM, 40-SEG, 1/4 Bias) LCD library source file
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "NuMicro.h"

#include "lcdlib.h"

uint8_t container[15][8];

/** @addtogroup Library Library
  @{
*/

/** @addtogroup LCDLIB LCD Library
  @{
*/

/** @addtogroup LCDLIB_EXPORTED_FUNCTIONS LCD Library Exported Functions
  @{
*/

/**
 *  @brief Display text on LCD
 *
 *  @param[in]  u32Zone     the assigned number of display area
 *  @param[in]  InputStr    Text string to show on display
 *
 *  @return None
 */
 

void LCDLIB_Printf(uint32_t u32Zone, char *InputStr)
{
    uint32_t    i, index, len;
    uint32_t    com, seg;
    int32_t     ch;

    len = strlen(InputStr);

    /* Fill out all characters on display */
    for (index = 0; index < g_LCDZoneInfo[u32Zone].u8LCDDispTableNum; index++)
    {
        if (index < len)
        {
            ch = *InputStr;
        }
        else
        {
            /* Padding with SPACE */
            ch = 0x20;
        }

        /* For Main Zone */ 
        uint16_t    DispData;

        /* For Other Zones (Support '0' ~ '9' only) */
        if ((ch >= '0') && (ch <= '9') && (g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum == DIGITAL_SEG_NUM_7))
        {
            ch = ch - '0';
            DispData = *(g_LCDZoneInfo[u32Zone].pu16LCDDispTable + ch);
        }
        /* Out of definition. Will show "SPACE" */
        else
        {
            DispData = 0;
        }

        for (i = 0; i < g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum; i++)
        {
            com = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 0);
            seg = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 1);

            if (DispData & (1 << i))
            {
                /* Turn on display */
                LCD_SetPixel(com, seg, 1);
            }
            else
            {
                /* Turn off display */
                LCD_SetPixel(com, seg, 0);
            }
        }

        InputStr++;
    }
}

/**
 *  @brief Display number on LCD
 *
 *  @param[in]  u32Zone     the assigned number of display area
 *  @param[in]  InputNum    number to show on display
 *
 *  @return None
 */
void LCDLIB_PrintNumber(uint32_t u32Zone, uint32_t InputNum)
{
    uint32_t    i, div;
    uint32_t    com, seg;

    /* Extract useful digits */
    div = 1;

    /* Fill out all characters on display */
    uint32_t index;

    index = g_LCDZoneInfo[u32Zone].u8LCDDispTableNum;

    while (index != 0)
    {
        index--;

        uint32_t val;

        val = (InputNum / div) % 10;

        if (g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum == DIGITAL_SEG_NUM_14)
            val += 16; /* The Main Digit Table is an ASCII table beginning with "SPACE" */

        uint16_t    DispData;

        DispData = *(g_LCDZoneInfo[u32Zone].pu16LCDDispTable + val);

        for (i = 0; i < g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum; i++)
        {
            com = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 0);
            seg = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 1);

            if (DispData & (1 << i))
            {
                /* Turn on display */
                LCD_SetPixel(com, seg, 1);
            }
            else
            {
                /* Turn off display */
                LCD_SetPixel(com, seg, 0);
            }
        }

        div = div * 10;
    }
}


/**
 *  @brief Display character on LCD
 *
 *  @param[in]  u32Zone     the assigned number of display area
 *  @param[in]  u32Index    the requested display position in zone
 *  @param[in]  u8Ch        Character to show on display
 *
 *  @return None
 */
void LCDLIB_PutChar(uint32_t u32Zone, uint32_t u32Index, uint8_t u8Ch)
{

    if (u32Index <= g_LCDZoneInfo[u32Zone].u8LCDDispTableNum)
    {
        uint32_t    ch;
        uint16_t    DispData;

        /* For Main Zone */
        if (g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum == DIGITAL_SEG_NUM_14)
        {
            /* Defined letters currently starts at "SPACE" - 0x20; */
            ch       = u8Ch - 0x20;
            DispData = *(g_LCDZoneInfo[u32Zone].pu16LCDDispTable + ch);
        }
        /* For Other Zones (Support '0' ~ '9' only) */
        else if ((u8Ch >= '0') && (u8Ch <= '9') && (g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum == DIGITAL_SEG_NUM_7))
        {
            u8Ch = u8Ch - '0';
            DispData = *(g_LCDZoneInfo[u32Zone].pu16LCDDispTable + u8Ch);
        }
        /* Out of definition. Will show "SPACE" */
        else
        {
            DispData = 0;
        }

        uint32_t    i;

        for (i = 0; i < g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum; i++)
        {
            uint32_t    com, seg;

            com = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (u32Index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 0);

            seg = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
                    + (u32Index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
                    + (i * 2) + 1);

            if (DispData & (1 << i))
            {
                /* Turn on display */
                LCD_SetPixel(com, seg, 1);
            }
            else
            {
                /* Turn off display */
                LCD_SetPixel(com, seg, 0);
            }
        }
    }
}

void LCDLIB_DotMatrixPutChar(uint32_t u32Zone, uint32_t u32Index, uint8_t u8Ch)
{
		uint16_t    DispData;
		uint32_t    i;

		DispData = u8Ch;
		for (i = 0; i < g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum; i++)
		{
				uint32_t    com, seg;

				com = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
								+ (u32Index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
								+ (i * 2) + 0);

				seg = *(g_LCDZoneInfo[u32Zone].pu8GetLCDComSeg
								+ (u32Index * g_LCDZoneInfo[u32Zone].u8GetLCDComSegNum * 2)
								+ (i * 2) + 1);

				if (DispData & (1 << i))
				{
						/* Turn on display */
						LCD_SetPixel(com, seg, 1);
				}
				else
				{
						/* Turn off display */
						LCD_SetPixel(com, seg, 0);
				}
		}
}

/**
 *  @brief Display symbol on LCD
 *
 *  @param[in]  u32Symbol   the combination of com, seg position
 *  @param[in]  u32OnOff    1: display symbol
 *                          0: not display symbol
 *
 *  @return     None
 */
void LCDLIB_SetSymbol(uint32_t u32Symbol, uint32_t u32OnOff)
{
    uint32_t com, seg;

    com = (u32Symbol & 0xF);
    seg = ((u32Symbol & 0xFF0) >> 4);

    if (u32OnOff)
        LCD_SetPixel(com, seg, 1); /* Turn on display */
    else
        LCD_SetPixel(com, seg, 0); /* Turn off display */
}


void LCDLIB_SetSymbol_Position(uint8_t x,uint8_t y,uint8_t OnOff)
{
 		/*			container=[0][x]         */
		if((x==0)&&(y==0))
		{	container[0][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_1,	OnOff);} 
		if((x==1)&&(y==0))
		{	container[0][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_2,	OnOff);}
		if((x==2)&&(y==0))
		{	container[0][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_3,	OnOff);}
		if((x==3)&&(y==0))
		{	container[0][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_4,	OnOff);}
		if((x==4)&&(y==0))
		{	container[0][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_5,	OnOff);}
		if((x==5)&&(y==0))
		{	container[0][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_6,	OnOff);}
		if((x==6)&&(y==0))
		{	container[0][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_7,	OnOff);}
		if((x==7)&&(y==0))
		{	container[0][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_8,	OnOff);} 

		/*     container=[1][x]         */
		if((x==0)&&(y==1))
		{	container[1][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_9,	OnOff);}
		if((x==1)&&(y==1))
		{	container[1][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_10,	OnOff);}
		if((x==2)&&(y==1))
		{	container[1][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_11,	OnOff);}
		if((x==3)&&(y==1))
		{	container[1][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_12,	OnOff);}
		if((x==4)&&(y==1))
		{	container[1][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_13,	OnOff);}
		if((x==5)&&(y==1))
		{	container[1][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_14,	OnOff);}
		if((x==6)&&(y==1))
		{	container[1][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_15,	OnOff);}
		if((x==7)&&(y==1))
		{	container[1][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_16,	OnOff);}
		
		/*     container=[2][x]         */
		if((x==0)&&(y==2))
		{	container[2][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_17,	OnOff);}
		if((x==1)&&(y==2))
		{	container[2][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_18,	OnOff);}
		if((x==2)&&(y==2))
		{	container[2][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_19,	OnOff);}
		if((x==3)&&(y==2))
		{	container[2][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_20,	OnOff);}
		if((x==4)&&(y==2))
		{	container[2][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_21,	OnOff);}
		if((x==5)&&(y==2))
		{	container[2][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_22,	OnOff);}
		if((x==6)&&(y==2))
		{	container[2][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_23,	OnOff);}
		if((x==7)&&(y==2))
		{	container[2][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_24,	OnOff);}
		
		/*     container=[3][x]         */
		if((x==0)&&(y==3))
		{	container[3][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_25,	OnOff);}
		if((x==1)&&(y==3))
		{	container[3][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_26,	OnOff);}
		if((x==2)&&(y==3))
		{	container[3][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_27,	OnOff);}
		if((x==3)&&(y==3))
		{	container[3][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_28,	OnOff);}
		if((x==4)&&(y==3))
		{	container[3][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_29,	OnOff);}
		if((x==5)&&(y==3))
		{	container[3][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_30,	OnOff);}
		if((x==6)&&(y==3))
		{	container[3][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_31,	OnOff);}
		if((x==7)&&(y==3))
		{	container[3][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_32,	OnOff);}		
		
		/*     container=[4][x]         */
		if((x==0)&&(y==4))
		{	container[4][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_33,	OnOff);}
		if((x==1)&&(y==4))
		{	container[4][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_34,	OnOff);}
		if((x==2)&&(y==4))
		{	container[4][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_35,	OnOff);}
		if((x==3)&&(y==4))
		{	container[4][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_36,	OnOff);}
		if((x==4)&&(y==4))
		{	container[4][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_37,	OnOff);}
		if((x==5)&&(y==4))
		{	container[4][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_38,	OnOff);}
		if((x==6)&&(y==4))
		{	container[4][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_39,	OnOff);}
		if((x==7)&&(y==4))
		{	container[4][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_40,	OnOff);}		
		
		/*     container=[5][x]         */
		if((x==0)&&(y==5))
		{	container[5][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_41,	OnOff);}
		if((x==1)&&(y==5))
		{	container[5][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_42,	OnOff);}
		if((x==2)&&(y==5))
		{	container[5][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_43,	OnOff);}
		if((x==3)&&(y==5))
		{	container[5][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_44,	OnOff);}
		if((x==4)&&(y==5))
		{	container[5][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_45,	OnOff);}
		if((x==5)&&(y==5))
		{	container[5][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_46,	OnOff);}
		if((x==6)&&(y==5))
		{	container[5][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_47,	OnOff);}
		if((x==7)&&(y==5))
		{	container[5][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_48,	OnOff);}
		
		/*     container=[6][x]         */
		if((x==0)&&(y==6))
		{	container[6][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_49,	OnOff);}
		if((x==1)&&(y==6))
		{	container[6][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_50,	OnOff);}
		if((x==2)&&(y==6))
		{	container[6][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_51,	OnOff);}
		if((x==3)&&(y==6))
		{	container[6][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_52,	OnOff);}
		if((x==4)&&(y==6))
		{	container[6][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_53,	OnOff);}
		if((x==5)&&(y==6))
		{	container[6][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_54,	OnOff);}
		if((x==6)&&(y==6))
		{	container[6][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_55,	OnOff);}
		if((x==7)&&(y==6))
		{	container[6][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_56,	OnOff);}		
		
		/*     container=[7][x]         */
		if((x==0)&&(y==7))
		{	container[7][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_57,	OnOff);}
		if((x==1)&&(y==7))
		{	container[7][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_58,	OnOff);}
		if((x==2)&&(y==7))
		{	container[7][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_59,	OnOff);}
		if((x==3)&&(y==7))
		{	container[7][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_60,	OnOff);}
		if((x==4)&&(y==7))
		{	container[7][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_61,	OnOff);}
		if((x==5)&&(y==7))
		{	container[7][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_62,	OnOff);}
		if((x==6)&&(y==7))
		{	container[7][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_63,	OnOff);}
		if((x==7)&&(y==7))
		{	container[7][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_64,	OnOff);}			
		
		/*     container=[8][x]         */
		if((x==0)&&(y==8))
		{	container[8][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_65,	OnOff);}
		if((x==1)&&(y==8))
		{	container[8][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_66,	OnOff);}
		if((x==2)&&(y==8))
		{	container[8][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_67,	OnOff);}
		if((x==3)&&(y==8))
		{	container[8][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_68,	OnOff);}
		if((x==4)&&(y==8))
		{	container[8][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_69,	OnOff);}
		if((x==5)&&(y==8))
		{	container[8][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_70,	OnOff);}
		if((x==6)&&(y==8))
		{	container[8][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_71,	OnOff);}
		if((x==7)&&(y==8))
		{	container[8][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_72,	OnOff);}			
		
		/*     container=[9][x]         */
		if((x==0)&&(y==9))
		{	container[9][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_73,	OnOff);}
		if((x==1)&&(y==9))
		{	container[9][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_74,	OnOff);}
		if((x==2)&&(y==9))
		{	container[9][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_75,	OnOff);}
		if((x==3)&&(y==9))
		{	container[9][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_76,	OnOff);}
		if((x==4)&&(y==9))
		{	container[9][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_77,	OnOff);}
		if((x==5)&&(y==9))
		{	container[9][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_78,	OnOff);}
		if((x==6)&&(y==9))
		{	container[9][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_79,	OnOff);}
		if((x==7)&&(y==9))
		{	container[9][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_80,	OnOff);}
		
		/*     container=[10][x]         */
		if((x==0)&&(y==10))
		{	container[10][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_81,	OnOff);}
		if((x==1)&&(y==10))
		{	container[10][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_82,	OnOff);}
		if((x==2)&&(y==10))
		{	container[10][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_83,	OnOff);}
		if((x==3)&&(y==10))
		{	container[10][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_84,	OnOff);}
		if((x==4)&&(y==10))
		{	container[10][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_85,	OnOff);}
		if((x==5)&&(y==10))
		{	container[10][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_86,	OnOff);}
		if((x==6)&&(y==10))
		{	container[10][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_87,	OnOff);}
		if((x==7)&&(y==10))
		{	container[10][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_88,	OnOff);}

		/*     container=[11][x]         */
		if((x==0)&&(y==11))
		{	container[11][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_89,	OnOff);}
		if((x==1)&&(y==11))
		{	container[11][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_90,	OnOff);}
		if((x==2)&&(y==11))
		{	container[11][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_91,	OnOff);}
		if((x==3)&&(y==11))
		{	container[11][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_92,	OnOff);}
		if((x==4)&&(y==11))
		{	container[11][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_93,	OnOff);}
		if((x==5)&&(y==11))
		{	container[11][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_94,	OnOff);}
		if((x==6)&&(y==11))
		{	container[11][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_95,	OnOff);}
		if((x==7)&&(y==11))
		{	container[11][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_96,	OnOff);}

		/*     container=[12][x]         */
		if((x==0)&&(y==12))
		{	container[12][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_97,	OnOff);}
		if((x==1)&&(y==12))
		{	container[12][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_98,	OnOff);}
		if((x==2)&&(y==12))
		{	container[12][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_99,	OnOff);}
		if((x==3)&&(y==12))
		{	container[12][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_100,	OnOff);}
		if((x==4)&&(y==12))
		{	container[12][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_101,	OnOff);}
		if((x==5)&&(y==12))
		{	container[12][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_102,	OnOff);}
		if((x==6)&&(y==12))
		{	container[12][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_103,	OnOff);}
		if((x==7)&&(y==12))
		{	container[12][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_104,	OnOff);}
		
		/*     container=[13][x]         */
		if((x==0)&&(y==13))
		{	container[13][0]=OnOff;	LCDLIB_SetSymbol(SYMBOL_105,	OnOff);}
		if((x==1)&&(y==13))
		{	container[13][1]=OnOff;	LCDLIB_SetSymbol(SYMBOL_106,	OnOff);}
		if((x==2)&&(y==13))
		{	container[13][2]=OnOff;	LCDLIB_SetSymbol(SYMBOL_107,	OnOff);}
		if((x==3)&&(y==13))
		{	container[13][3]=OnOff;	LCDLIB_SetSymbol(SYMBOL_108,	OnOff);}
		if((x==4)&&(y==13))
		{	container[13][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_109,	OnOff);}
		if((x==5)&&(y==13))
		{	container[13][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_110,	OnOff);}
		if((x==6)&&(y==13))
		{	container[13][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_111,	OnOff);}
		if((x==7)&&(y==13))
		{	container[13][7]=OnOff;  LCDLIB_SetSymbol(SYMBOL_112,	OnOff);	}

		/*     container=[14][x]         */
		if((x==0)&&(y==14))
		{	container[14][0]=OnOff; LCDLIB_SetSymbol(SYMBOL_113,	OnOff);		}
		if((x==1)&&(y==14))
		{	container[14][1]=OnOff;LCDLIB_SetSymbol(SYMBOL_114,	OnOff); 	}
		if((x==2)&&(y==14))
		{	container[14][2]=OnOff;LCDLIB_SetSymbol(SYMBOL_115,	OnOff);	}
		if((x==3)&&(y==14))
		{	container[14][3]=OnOff;LCDLIB_SetSymbol(SYMBOL_116,	OnOff);		}
		if((x==4)&&(y==14))
		{	container[14][4]=OnOff;	LCDLIB_SetSymbol(SYMBOL_117,	OnOff);}
		if((x==5)&&(y==14))
		{	container[14][5]=OnOff;	LCDLIB_SetSymbol(SYMBOL_118,	OnOff);	}
		if((x==6)&&(y==14))
		{	container[14][6]=OnOff;	LCDLIB_SetSymbol(SYMBOL_119,	OnOff);}
		if((x==7)&&(y==14))
		{	container[14][7]=OnOff;	LCDLIB_SetSymbol(SYMBOL_120,	OnOff);	}					
}

/*@}*/ /* end of group LCDLIB_EXPORTED_FUNCTIONS */

/*@}*/ /* end of group LCDLIB */

/*@}*/ /* end of group Library */
