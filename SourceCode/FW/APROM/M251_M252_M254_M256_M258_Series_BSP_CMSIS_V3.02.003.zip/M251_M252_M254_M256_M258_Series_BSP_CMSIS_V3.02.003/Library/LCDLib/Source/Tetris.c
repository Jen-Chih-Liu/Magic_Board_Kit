#include "Tetris.h"
#include <stdlib.h> 
#include "lcdlib.h"
#include <stdio.h>

//const int BLOCK_INIT_POSX = (TETRIS_CONTAINER_WIDTH - BLOCK_WIDTH) / 2; //(10-4)/2  
//const int BLOCK_INIT_POSY = 2;
const unsigned long EMPTY_LINE = 0x0000; //0x0201
//unsigned long blockContainer[TETRIS_CONTAINER_HIGHT];
//uint8_t Block_Type_G[2][6][6]={{{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}},{{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}}};
uint8_t Block_Type_G[2][4][4]={{{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}},{{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}}};
uint8_t Block_Type[4][4]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
//uint8_t Block_Type[6][6]={{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};

uint8_t rand_x[100],rand_y[100];	
static unsigned short gBlockList[BT_NUM][BS_NUM] = {
	{0x0630, 0x0132, 0x0630, 0x0132}, //S
	{0x0360, 0x0231, 0x0360, 0x0231}, //Z
	{0x0170, 0x0223, 0x0074, 0x0622}, //J
	{0x0470, 0x0322, 0x0071, 0x0226}, //L
	{0x00F0, 0x2222, 0x00F0, 0x2222}, //I
	{0x0270, 0x0232, 0x0072, 0x0262}, //T
	{0x0660, 0x0660, 0x0660, 0x0660}  //O
};
	
/*static unsigned short gBlockList[BT_NUM][BS_NUM] = {
	{0x0630, 0x1320, 0x0630, 0x1320}, //S
	{0x0360, 0x2310, 0x0360, 0x2310}, //Z
	{0x0170, 0x2230, 0x0740, 0x6220}, //J
	{0x0470, 0x3220, 0x0710, 0x2260}, //L
	{0x00F0, 0x2222, 0x00F0, 0x2222}, //I
	{0x0270, 0x2320, 0x0720, 0x2620}, //T
	{0x0660, 0x0660, 0x0660, 0x0660}  //O
};*/
uint8_t current_block;
uint8_t b=0;
uint8_t x_1=0;
uint8_t statemode,typemode;
extern uint8_t state;
extern uint8_t type;
//uint8_t y=0;

/*int randint(int n) 
{
  if ((n - 1) == RAND_MAX) 
	{
    return rand();
  } 
	else 
	{
    long end = RAND_MAX / n;
    assert (end > 0L);
    end *= n;

    int r;
    while ((r = rand()) >= end);
    return r % n;
  }
}*/

void rand_block()
{
	for(uint8_t i=0;i<100;i++)	
	{	
		//srand(3);		
		rand_x[i]=rand() % 6;
	}
	for(uint8_t i=0;i<100;i++)	
	{	
		//srand(7);		
		rand_y[i]=rand() % 3;
	}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
}

//uint8_t k=0;
//uint8_t x=0;
//uint8_t y=0;
void block_test(Block block,uint8_t r,uint8_t c,unsigned long seed_time,uint8_t keymode)
{
		//Block* block_1=block;
		//Block* block; 
		Tetris* tetris;	
	  //block_1.row=0;
    //block_1.col=0;

		block.row = r;
    block.col = c;
		block.type = rand() % 6;
    block.state = rand() % 3;
	//block.type = 0;
    //block.state = 0;
		//*block=tetris.blocks[i_1];
		//uint8_t Block_Type[4][4]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
		/*unsigned short blk = gBlockList[0][1];
		for(uint8_t i=0;i<4;i++)
		{
				unsigned short bits= (blk >> (i * 4)  & 0x000F); 
				unsigned short bits_copy=bits;
				unsigned short j;
				bits= bits%2;
				for(j=0; bits_copy>0; j++)   
				{	    
					Block_Type[1][i][j]=bits_copy%2;    
					bits_copy= bits_copy/2;			   
				}    
		}*/
		//displayBlock(r,c,1);

		rand_block();
		++b;	
		
		//blk[1] = gBlockList[rand_x[x]][keymode];
		if(b==1)
		{
		
			//unsigned short bits;
			//unsigned short bits_copy;
			unsigned short blk;
			for(uint8_t i_1=0;i_1<2;i_1++)
			{
				//srand(seed_time);
				
				if(i_1==1)
					{
						//srand(seed_time);
						blk = gBlockList[block.type][block.state]; //current
					}
					if(i_1==0)
					{
							blk = gBlockList[block.type][block.state];  //next
					}
				for(uint8_t j=0;j<4;j++)
				{
					unsigned short bits= (blk >> (j * 4)  & 0x000F);
					unsigned short bits_copy=bits;
					unsigned short i;
					bits= bits%2;
					for(i=3; bits_copy>0; i--)    
					{	    
						Block_Type_G[i_1][i][j]=bits_copy%2;    
						bits_copy= bits_copy/2; 
					}
				}
		
		}
			for(uint8_t i = 0; i <4; i++)
			{
				for(uint8_t j = 0; j <4; j++)
				{	
					LCDLIB_SetSymbol_NextBlock(i,j, Block_Type_G[0][i][j]); 	//block next		
				}
			}		
		}
		
			for(uint8_t i = r; i < r+4; i++)
			{
				for(uint8_t j = c; j < c+4; j++)
				{
			//if(c!=12)
			//{
				//LCDLIB_SetSymbol_Position(i,j-3, 0); 
			//}
			//if((Search_Block_Onoff(0,14)==0)||(Search_Block_Onoff(1,14)==0)||(Search_Block_Onoff(2,14)==0)||(Search_Block_Onoff(3,14)==0)
				//||(Search_Block_Onoff(4,14)==0)||(Search_Block_Onoff(5,14)==0)||(Search_Block_Onoff(6,14)==0)||(Search_Block_Onoff(7,14)==0))
			//{
				//LCDLIB_SetSymbol_Position(i,j, Block_Type[1][i-r][j-c]);
					
			//}
					
				if(c<=12)
				{
					//c=0;
					//Block_Type[0][i][j]=Block_Type[1][i][j];
					LCDLIB_SetSymbol_Position(i,j, Block_Type_G[1][i-r][j-c]);
					if(c==12)
					{
						c=0;
					for(uint8_t i = 0; i <4; i++)
					{
						for(uint8_t j = 0; j <4; j++)
						{	
							//Block_Type[1][i][j]=Block_Type[0][i][j];
							LCDLIB_SetSymbol_Position(i,j, Block_Type_G[1][i][j]);			
						}
					}	
					//b=0;
									
					}
					
					
					//c=0;
				}
				/*else if(c==12)
				{
					for(uint8_t i = 0; i <4; i++)
					{
						for(uint8_t j = 0; j <4; j++)
						{	
							Block_Type[0][i][j]=Block_Type[1][i][j];
							LCDLIB_SetSymbol_Position(i,j, Block_Type[0][i][j]);			
						}
					}	
					b=0;						
				}*/
					
				}
			
			}		
	
}	
void displayBlock(uint8_t r,uint8_t c, uint8_t a)
{
	for(uint8_t i = r; i < r+4; i++)
		{
			for(uint8_t j = c; j < c+4; j++)
			{
				if(a==1)
				{
				//LCDLIB_SetSymbol_Position(i,j, Block_Type[i-r][j-c]);
				}
				if(a==0)
				{	
					//LCDLIB_SetSymbol_Position(i,j, 0);
				}					
			}
		}	
}

void HexToBinary(Tetris tetris,Block block, uint8_t keymode, uint8_t state)
{
		unsigned short blk;
		statemode = state;
		if(keymode!=4)
		{
			blk= gBlockList[typemode][statemode];
		}
		if(keymode==4)
		{
			++statemode;
			++typemode;
		
		}
		for(uint8_t k=0;k<2;k++)
		{
			statemode=statemode % BS_NUM;	
			typemode=typemode % BT_NUM;
			tetris.blocks[k].type=typemode;
			tetris.blocks[k].state=statemode;
			blk= gBlockList[typemode][statemode];
			
			for(uint8_t j=0;j<4;j++)
			{
				unsigned short bits= (blk >> (j * 4)  & 0x000F); 
				unsigned short bits_copy=bits;
				bits=bits%2;
				for(unsigned short i=0; i<4; i++)
				{
					Block_Type[i][j]=bits_copy%2;    
					bits_copy= bits_copy/2;	
				
					Block_Type_G[k][i][j]=Block_Type[i][j];			
					
				}	  
			}
			
	}
}

/*void initRandBlock(Block block, uint8_t r_, uint8_t c_, uint8_t keymode)
{
	 block.row = r_; //block row
	 block.col = c_; //block column
	 HexToBinary(block,keymode,state);			
	 for(uint8_t j = 0; j <4; j++)
		{
				for(uint8_t i = 0; i <4; i++)
				{	
					LCDLIB_SetSymbol_NextBlock(i,j, Block_Type[i][j]); 	//block next					
				}
		}		
		for(uint8_t i = r_; i < r_+4; i++)
		{
				for(uint8_t j = c_; j < c_+4; j++)
				{
					Block_Type_G[1][i-r_][j-c_]=Block_Type[i-r_][j-c_];
				}
		}
}*/



void init_Block_Container(uint8_t r_1,uint8_t c_1)
{ 
	  
	//Tetris *tetris;
	//uint8_t r = tetris.blocks[0].row;
	//uint8_t c = tetris.blocks[0].col;
	//uint8_t Block_Type[4][4]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	//BLOCK_HIGHT +BLOCK_IMAGE_HIGHT+1=4+15+1=20
	//for (uint8_t i = 0; i < TETRIS_CONTAINER_HIGHT; i++)
	//{
    //tetris.blockContainer[i] = EMPTY_LINE; 
		//EMPTY_LINE=0x0201, B001000000001
	//}

	//tetris.blockContainer[TETRIS_CONTAINER_HIGHT - 1] = 0x03FF; 
				 //(HEX)0xFFFF = B001111111111
	
	//tetris.blockIndex = 0;
	//for (uint8_t i = 0; i < TETRIS_BLOCK_NUM; i++)
	//{
	
   
		//BLOCK_INIT_POSX=(TETRIS_CONTAINER_WIDTH - BLOCK_WIDTH) / 2=(8-4)/2
		//BLOCK_INIT_POSY=2
		//TETRIS_BLOCK_NUM=2 (NOW Block, Next Block)
	//}	
}	


int moveLeft(Block block) //block moveLeft
{
    //if(block)
    //{
        block.col -= 1;
    //}
    return 0;
}

int moveRight(Block block) //block moveRight
{
    //if (block)
    //{
        block.col += 1;
    //}
    return 0;
}

int moveDown(Block block) //block moveDown
{
    //if (block)
    //{
        block.row += 1;
    //}
    return 0;
}

int rotate(Block block) //block rotate
{
    block.state = (block.state + 1) % BS_NUM;
    return 0;
}

int hitTest(const Block block, const Tetris tetris)   //block Collision detection
{
    unsigned short blk = gBlockList[block.type][block.state];
    for (int i = 0; i < BLOCK_HIGHT; i++)					
    {
        unsigned short bits = ((blk >> (i * BLOCK_WIDTH)) & 0x000F);
        //block.col may be negative
        if (block.col < 0)
        {
            bits >>= (-block.col);
        }
        else
        {
            bits <<= block.col;
        }
        if (tetris.blockContainer[block.row + i] & bits)
        {
            return 1;
        }
    }
    return 0;
}


void merge(Block block, Tetris tetris)  //block merge detection
{
    unsigned short blk = gBlockList[block.type][block.state];
    for (int i = 0; i < BLOCK_HIGHT; i++)
    {
        unsigned short bits = ((blk >> (i * BLOCK_WIDTH)) & 0x000F);
        //block.col may be negative
        if (block.col < 0)
        {
            bits >>= (-block.col);
        }
        else
        {
            bits <<= block.col;
        }
        tetris.blockContainer[block.row + i] |= bits;
    }
}

int moveLeftBlock(Tetris tetris)
{
	/*if (!tetris) 
	{
		return -1;
	}*/
	Block currBlock = tetris.blocks[tetris.blockIndex];		//now block
	Block next = currBlock;	//state after moving
	moveLeft(next);
	if (hitTest(next, tetris)) 
	{
		return 0;	/* detect that the block in the next state will collide, 
		then cancel the movement */
	}
	moveLeft(currBlock);	/* if there is no collision, complete the move */

	return 0;
}


int moveDownTest(Tetris tetris, Block currBlock)
{
	/*if (!tetris) 
	{
		return -1;
	}
	*/
	currBlock = tetris.blocks[tetris.blockIndex];		//now block
	Block next = currBlock;	//state after moving
	 next.row += 1;
	//moveDown(next);
	if (hitTest(next, tetris)) 
	{
		return 0;	/* detect that the block in the next state will collide, 
		then cancel the movement */
	}
	moveDown(currBlock);	/* if there is no collision, complete the move */
	return 0;
}
int u;
int moveDownBlock(Tetris tetris, uint8_t x, uint8_t y ,uint8_t keymode, uint8_t state)
{
	
	Block currBlock = tetris.blocks[tetris.blockIndex]; //current block
	HexToBinary(tetris,currBlock,keymode,state);
	if(keymode==1)
	{	
		tetris.blocks[0].row=x;
		tetris.blocks[0].col=y;
		//currBlock.row=x;
		//currBlock.col=y;
	}
	if(keymode==2)
	{
		tetris.blocks[0].row=x;
		tetris.blocks[0].col=y;
		//currBlock.row=x;
		//currBlock.col=y;
	}
	if(keymode==3)
	{
		tetris.blocks[0].row=x;
		tetris.blocks[0].col=y;
		//currBlock.row=x;
		//currBlock.col=y;
	}
	if(keymode==4)
	{
		tetris.blocks[0].row=x;
		tetris.blocks[0].col=y;
		//currBlock.row=x;
		//currBlock.col=y;		
	}	
	for(uint8_t i = 0; i <4; i++)
	{
				for(uint8_t j = 0; j <4; j++)
				{	
						LCDLIB_SetSymbol_NextBlock(i,j, Block_Type_G[0][i][j]); 	//block next		
				}
	}	
	for(uint8_t i = currBlock.row; i <currBlock.row+4; i++)
	{ 
				for(uint8_t j = currBlock.col; j <currBlock.col+4; j++)
				{
						LCDLIB_SetSymbol_Position(j,i, Block_Type_G[1][j-currBlock.col][i-currBlock.row]);
				}
	}
	eraseLines(tetris);
	return 0;
}


static void eraseLines(Tetris tetris)
{
	//scan from bottom to top
	int line = TETRIS_CONTAINER_HIGHT - 2; 
	//TETRIS_CONTAINER_HIGHT=BLOCK_HIGHT + BLOCK_IMAGE_HIGHT + 1 //4+15+1=20
	int afterLine = line;
	int eraseLine = 0;
	while (line >= BLOCK_HIGHT)
	{
		if (0x0FFF != (tetris.blockContainer[line] & 0x0FFF))	//if the current row is not full
		{ 
		afterLine--;
		}//record the number of reduced rows
		else
		{ 
			eraseLine++;
		}
		line--;
		if (afterLine != line) 
		{	
			tetris.blockContainer[afterLine] = tetris.blockContainer[line];
		}
	}
	while (afterLine >= BLOCK_HIGHT) 
	{
		tetris.blockContainer[--afterLine] = EMPTY_LINE;	//record the number of reduced rows
	}
}

//??


void renderBlock(Block block,unsigned char alpha)
{
    //SDL_Rect rt = {0, 0, BLOCK_IMAGE_WIDTH, BLOCK_IMAGE_HIGHT};
    for (int i = 0; i < BLOCK_HIGHT; i++)
    {
        for (int j = 0; j < BLOCK_WIDTH; j++)
        {
            //?????????
            if ((1 << j << (i * BLOCK_WIDTH)) & (gBlockList[block.type][block.state]))
            {
                //rt.x = (block.col + j - 1) * BLOCK_IMAGE_WIDTH;
                //rt.y = (block.row + i - BLOCK_HIGHT) * BLOCK_IMAGE_HIGHT;
                //SDL_SetTextureAlphaMod(getResource(RES_TEXTURE), alpha);
                //SDL_RenderCopy(pModule.pRenderer, getResource(RES_TEXTURE), getTileRect(TT_FK), &rt);
                //SDL_SetTextureAlphaMod(getResource(RES_TEXTURE), 255);
            }
        }
    }
}

