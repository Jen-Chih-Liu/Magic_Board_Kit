/**************************************************************************//**
 * @file     lcdzone.h
 * @version  V1.00
 * @brief    RHE6616TP01(8-COM, 40-SEG, 1/4 Bias) LCD zone header file
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#ifndef __LCDZONE_H
#define __LCDZONE_H

#ifdef __cplusplus
extern "C"
{
#endif

/** @addtogroup Library Library
  @{
*/

/** @addtogroup LCDLIB LCD Library
  @{
*/

/** @addtogroup LCDLIB_EXPORTED_CONSTANTS LCD Zone Exported Constants
  @{
*/
/*---------------------------------------------------------------------------------------------------------*/
/*  Digit Zone Constant Definitions                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
#define ZONE_SCORE_DIGIT										0
#define ZONE_TIME_DIGIT										1
#define ZONE_MAIN_DOT_MATRIX_DIGIT										2

/*---------------------------------------------------------------------------------------------------------*/
/*  COM and SEG Position of Symbol Constant Definitions                                                    */
/*---------------------------------------------------------------------------------------------------------*/
#define SYMBOL_1										((11)<<4 | (0)<<0)
#define SYMBOL_2										((11)<<4 | (1)<<0)
#define SYMBOL_3										((11)<<4 | (2)<<0)
#define SYMBOL_4										((11)<<4 | (3)<<0)
#define SYMBOL_5										((11)<<4 | (4)<<0)
#define SYMBOL_6										((11)<<4 | (5)<<0)
#define SYMBOL_7										((11)<<4 | (6)<<0)
#define SYMBOL_8										((11)<<4 | (7)<<0)
#define SYMBOL_9										((12)<<4 | (0)<<0)
#define SYMBOL_10										((12)<<4 | (1)<<0)
#define SYMBOL_11										((12)<<4 | (2)<<0)
#define SYMBOL_12										((12)<<4 | (3)<<0)
#define SYMBOL_13										((12)<<4 | (4)<<0)
#define SYMBOL_14										((12)<<4 | (5)<<0)
#define SYMBOL_15										((12)<<4 | (6)<<0)
#define SYMBOL_16										((12)<<4 | (7)<<0)
#define SYMBOL_17										((13)<<4 | (0)<<0)
#define SYMBOL_18										((13)<<4 | (1)<<0)
#define SYMBOL_19										((13)<<4 | (2)<<0)
#define SYMBOL_20										((13)<<4 | (3)<<0)
#define SYMBOL_21										((13)<<4 | (4)<<0)
#define SYMBOL_22										((13)<<4 | (5)<<0)
#define SYMBOL_23										((13)<<4 | (6)<<0)
#define SYMBOL_24										((13)<<4 | (7)<<0)
#define SYMBOL_25										((14)<<4 | (0)<<0)
#define SYMBOL_26										((14)<<4 | (1)<<0)
#define SYMBOL_27										((14)<<4 | (2)<<0)
#define SYMBOL_28										((14)<<4 | (3)<<0)
#define SYMBOL_29										((14)<<4 | (4)<<0)
#define SYMBOL_30										((14)<<4 | (5)<<0)
#define SYMBOL_31										((14)<<4 | (6)<<0)
#define SYMBOL_32										((14)<<4 | (7)<<0)
#define SYMBOL_33										((22)<<4 | (0)<<0)
#define SYMBOL_34										((22)<<4 | (1)<<0)
#define SYMBOL_35										((22)<<4 | (2)<<0)
#define SYMBOL_36										((22)<<4 | (3)<<0)
#define SYMBOL_37										((22)<<4 | (4)<<0)
#define SYMBOL_38										((22)<<4 | (5)<<0)
#define SYMBOL_39										((22)<<4 | (6)<<0)
#define SYMBOL_40										((22)<<4 | (7)<<0)
#define SYMBOL_41										((23)<<4 | (0)<<0)
#define SYMBOL_42										((23)<<4 | (1)<<0)
#define SYMBOL_43										((23)<<4 | (2)<<0)
#define SYMBOL_44										((23)<<4 | (3)<<0)
#define SYMBOL_45										((23)<<4 | (4)<<0)
#define SYMBOL_46										((23)<<4 | (5)<<0)
#define SYMBOL_47										((23)<<4 | (6)<<0)
#define SYMBOL_48										((23)<<4 | (7)<<0)
#define SYMBOL_49										((24)<<4 | (0)<<0)
#define SYMBOL_50										((24)<<4 | (1)<<0)
#define SYMBOL_51										((24)<<4 | (2)<<0)
#define SYMBOL_52										((24)<<4 | (3)<<0)
#define SYMBOL_53										((24)<<4 | (4)<<0)
#define SYMBOL_54										((24)<<4 | (5)<<0)
#define SYMBOL_55										((24)<<4 | (6)<<0)
#define SYMBOL_56										((24)<<4 | (7)<<0)
#define SYMBOL_57										((25)<<4 | (0)<<0)
#define SYMBOL_58										((25)<<4 | (1)<<0)
#define SYMBOL_59  										((25)<<4 | (2)<<0)
#define SYMBOL_60										((25)<<4 | (3)<<0)
#define SYMBOL_61										((25)<<4 | (4)<<0)
#define SYMBOL_62										((25)<<4 | (5)<<0)
#define SYMBOL_63										((25)<<4 | (6)<<0)
#define SYMBOL_64										((25)<<4 | (7)<<0)
#define SYMBOL_65										((26)<<4 | (0)<<0)
#define SYMBOL_66										((26)<<4 | (1)<<0)
#define SYMBOL_67										((26)<<4 | (2)<<0)
#define SYMBOL_68										((26)<<4 | (3)<<0)
#define SYMBOL_69										((26)<<4 | (4)<<0)
#define SYMBOL_70										((26)<<4 | (5)<<0)
#define SYMBOL_71										((26)<<4 | (6)<<0)
#define SYMBOL_72										((26)<<4 | (7)<<0)
#define SYMBOL_73										((27)<<4 | (0)<<0)
#define SYMBOL_74										((27)<<4 | (1)<<0)
#define SYMBOL_75										((27)<<4 | (2)<<0)
#define SYMBOL_76										((27)<<4 | (3)<<0)
#define SYMBOL_77										((27)<<4 | (4)<<0)
#define SYMBOL_78										((27)<<4 | (5)<<0)
#define SYMBOL_79										((27)<<4 | (6)<<0)
#define SYMBOL_80										((27)<<4 | (7)<<0)
#define SYMBOL_81										((35)<<4 | (0)<<0)
#define SYMBOL_82										((35)<<4 | (1)<<0)
#define SYMBOL_83										((35)<<4 | (2)<<0)
#define SYMBOL_84										((35)<<4 | (3)<<0)
#define SYMBOL_85										((35)<<4 | (4)<<0)
#define SYMBOL_86										((35)<<4 | (5)<<0)
#define SYMBOL_87										((35)<<4 | (6)<<0)
#define SYMBOL_88										((35)<<4 | (7)<<0)
#define SYMBOL_89										((36)<<4 | (0)<<0)
#define SYMBOL_90										((36)<<4 | (1)<<0)
#define SYMBOL_91										((36)<<4 | (2)<<0)
#define SYMBOL_92										((36)<<4 | (3)<<0)
#define SYMBOL_93										((36)<<4 | (4)<<0)
#define SYMBOL_94										((36)<<4 | (5)<<0)
#define SYMBOL_95										((36)<<4 | (6)<<0)
#define SYMBOL_96										((36)<<4 | (7)<<0)
#define SYMBOL_97										((37)<<4 | (0)<<0)
#define SYMBOL_98										((37)<<4 | (1)<<0)
#define SYMBOL_99									((37)<<4 | (2)<<0)
#define SYMBOL_100										((37)<<4 | (3)<<0)
#define SYMBOL_101										((37)<<4 | (4)<<0)
#define SYMBOL_102										((37)<<4 | (5)<<0)
#define SYMBOL_103										((37)<<4 | (6)<<0)
#define SYMBOL_104										((37)<<4 | (7)<<0)
#define SYMBOL_105										((38)<<4 | (0)<<0)
#define SYMBOL_106										((38)<<4 | (1)<<0)
#define SYMBOL_107										((38)<<4 | (2)<<0)
#define SYMBOL_108										((38)<<4 | (3)<<0)
#define SYMBOL_109										((38)<<4 | (4)<<0)
#define SYMBOL_110										((38)<<4 | (5)<<0)
#define SYMBOL_111										((38)<<4 | (6)<<0)
#define SYMBOL_112										((38)<<4 | (7)<<0)
#define SYMBOL_113										((39)<<4 | (0)<<0)
#define SYMBOL_114										((39)<<4 | (1)<<0)
#define SYMBOL_115										((39)<<4 | (2)<<0)
#define SYMBOL_116										((39)<<4 | (3)<<0)
#define SYMBOL_117										((39)<<4 | (4)<<0)
#define SYMBOL_118										((39)<<4 | (5)<<0)
#define SYMBOL_119										((39)<<4 | (6)<<0)
#define SYMBOL_120										((39)<<4 | (7)<<0)
#define SYMBOL_BAT_FRAME										((0)<<4 | (4)<<0)
#define SYMBOL_BAT_1										((0)<<4 | (6)<<0)
#define SYMBOL_BAT_2										((0)<<4 | (5)<<0)
#define SYMBOL_BAT_3										((0)<<4 | (7)<<0)
#define SYMBOL_WIFI										((0)<<4 | (3)<<0)
#define SYMBOL_SPEAKER									((0)<<4 | (2)<<0)
#define SYMBOL_NVT										((0)<<4 | (1)<<0)
#define SYMBOL_A1										((6)<<4 | (0)<<0)
#define SYMBOL_A2										((5)<<4 | (0)<<0)
#define SYMBOL_A3										((4)<<4 | (0)<<0)
#define SYMBOL_A4										((1)<<4 | (0)<<0)
#define SYMBOL_A5										((6)<<4 | (1)<<0)
#define SYMBOL_A6										((5)<<4 | (1)<<0)
#define SYMBOL_A7										((4)<<4 | (1)<<0)
#define SYMBOL_A8										((1)<<4 | (1)<<0)
#define SYMBOL_A9										((6)<<4 | (2)<<0)
#define SYMBOL_A10										((5)<<4 | (2)<<0)
#define SYMBOL_A11										((4)<<4 | (2)<<0)
#define SYMBOL_A12										((1)<<4 | (2)<<0)
#define SYMBOL_A13										((6)<<4 | (3)<<0)
#define SYMBOL_A14										((5)<<4 | (3)<<0)
#define SYMBOL_A15										((4)<<4 | (3)<<0)
#define SYMBOL_A16										((1)<<4 | (3)<<0)
#define SYMBOL_COL										((6)<<4 | (7)<<0)
#define SYMBOL_LINE										((0)<<4 | (0)<<0)
#define SYMBOL_SCORE										((10)<<4 | (3)<<0)
#define SYMBOL_NEXT										((8)<<4 | (3)<<0)
#define SYMBOL_TIME										((4)<<4 | (7)<<0)

/*@}*/ /* end of group LCDLIB_EXPORTED_CONSTANTS */



/** @addtogroup LCDLIB_EXPORTED_STRUCTS LCD Zone Exported Structs
  @{
 */
typedef struct
{
    unsigned char   u8LCDDispTableNum;          /*!< LCD Display Table Number */
    unsigned char   u8GetLCDComSegNum;          /*!< LCD Com Seg Table Number */
    unsigned short  *pu16LCDDispTable;          /*!< LCD Display Table Pointer */
    unsigned char   *pu8GetLCDComSeg;           /*!< LCD Com Seg Table Pointer */

} LCD_ZONE_INFO_T;

/*@}*/ /* end of group LCDLIB_EXPORTED_STRUCTS */



/** @addtogroup LCDLIB_EXPORTED_CONSTANTS LCD Zone Exported Constants
  @{
*/

#define ZONE_SCORE_DIG_CNT										2
#define ZONE_SCORE_SEG_NUM										7

#define ZONE_TIME_DIG_CNT										4
#define ZONE_TIME_SEG_NUM										7

#define ZONE_MAIN_DOT_MATRIX_DIG_CNT										15
#define ZONE_MAIN_DOT_MATRIX_SEG_NUM										8

#define ZONE_SCORE_DOT_MATRIX_DIG_CNT										4
#define ZONE_SCORE_DOT_MATRIX_SEG_NUM										4

/*@}*/ /* end of group LCDLIB_EXPORTED_CONSTANTS */


/** @addtogroup LCDLIB_EXPORTED_STRUCTS LCD Zone Exported Structs
  @{
 */

/**************************************************************************//**
*
* Defines each text's segment (alphabet+numeric) in terms of COM and SEG numbers,
* Using this way that text segment can be consisted of each bit in the
* following bit pattern:
*
*              A
*         -----------
*         |\   |   /|
*         F G  H  I B
*         |  \ | /  |
*         --J-- --K--
*         |   /| \  |
*         E  L M  N C
*         | /  |   \|
*         -----------
*              D
*
*              0
*         -----------
*         |\   |   /|
*        5| 6  7  8 |1
*         |  \ | /  |
*         --9-- -10--
*         |   /| \  |
*        4| 11 12 13|2
*         | /  |   \|
*         -----------
*              3
*
*****************************************************************************/


/**************************************************************************//**
*
* Defines each text's segment (numeric) in terms of COM and BIT numbers,
* Using this way that text segment can be consisted of each bit in the
* following bit pattern:
*
*         ---A---
*         |     |
*         F     B
*         |     |
*         ---G---
*         |     |
*         E     C
*         |     |
*         ---D---
*
*         ---0---
*         |     |
*         5     1
*         |     |
*         ---6---
*         |     |
*         4     2
*         |     |
*         ---3---
*
*****************************************************************************/

static const char acScoreDigitRawData[ZONE_SCORE_DIG_CNT][ZONE_SCORE_SEG_NUM][2] =
{
	{
		{0, 9}, 		{1, 9}, 		{2, 9}, 		{3, 9}, 		{2, 10}, 		{0, 10}, 		{1, 10}, 
	},
	{
		{0, 7}, 		{1, 7}, 		{2, 7}, 		{3, 7}, 		{2, 8}, 		{0, 8}, 		{1, 8}, 
	},
};
static const char acTimeDigitRawData[ZONE_TIME_DIG_CNT][ZONE_TIME_SEG_NUM][2] =
{
	//1A           1B            1C           1D           1E          1F           1G
	{
		{4, 9}, 		{5, 9}, 		{6, 9}, 		{7, 9}, 		{6, 10}, 		{4, 10}, 		{5, 10}, 
	},	
	{
		{4, 7}, 		{5, 7}, 		{6, 7}, 		{7, 7}, 		{6, 8}, 		{4, 8}, 		{5, 8}, 
	},
	{
		{4, 5}, 		{5, 5}, 		{6, 5}, 		{7, 5}, 		{6, 6}, 		{4, 6}, 		{5, 6}, 
	},
	{
		{4, 1}, 		{5, 1}, 		{6, 1}, 		{7, 1}, 		{6, 4}, 		{4, 4}, 		{5, 4}, 
	},
};

/**************************************************************************//**
*
* Defines segments for the alphabet - ASCII table 0x20 to 0x7A
* Bit pattern below defined for alphabet (text segments)
*
*****************************************************************************/


/**************************************************************************//**
* Defines segments for the numeric display
*****************************************************************************/

static const unsigned short auScoreDigitMap[] =
{
    0x3F, /* 0 */
    0x06, /* 1 */
    0x5B, /* 2 */
    0x4F, /* 3 */
    0x66, /* 4 */
    0x6D, /* 5 */
    0x7D, /* 6 */
    0x07, /* 7 */
    0x7F, /* 8 */
    0x6F, /* 9 */
};
static const unsigned short auTimeDigitMap[] =
{
    0x3F, /* 0 */
    0x06, /* 1 */
    0x5B, /* 2 */
    0x4F, /* 3 */
    0x66, /* 4 */
    0x6D, /* 5 */
    0x7D, /* 6 */
    0x07, /* 7 */
    0x7F, /* 8 */
    0x6F, /* 9 */
};
static const unsigned short auNullDigitMap[] =
{

};
static const char acMainDotDigitRawData[ZONE_MAIN_DOT_MATRIX_DIG_CNT][ZONE_MAIN_DOT_MATRIX_SEG_NUM][2] =
{
	{
		{0, 11}, 		{1, 11}, 		{2, 11}, 		{3, 11}, 		{4, 11}, 		{5, 11}, 		{6, 11}, 		{7, 11},//1-1~1-8
	},
	{
		{0, 12}, 		{1, 12}, 		{2, 12}, 		{3, 12}, 		{4, 12}, 		{5, 12}, 		{6, 12}, 		{7, 12},//2-1~2-8
	},
		{
		{0, 13}, 		{1, 13}, 		{2, 13}, 		{3, 13}, 		{4, 13}, 	  {5, 13}, 		{6, 13}, 		{7, 13},//3-1~3-8
	},
	{
		{0, 14}, 		{1, 14}, 		{2, 14}, 		{3, 14}, 		{4, 14}, 	  {5, 14}, 		{6, 14}, 		{7, 14},//4-1~4-8
	},
	{
		{0, 22}, 		{1, 22}, 		{2, 22}, 		{3, 22}, 		{4, 22}, 		{5, 22}, 		{6, 22}, 		{7, 22},//5-1~5-8
	},
	{
		{0, 23}, 		{1, 23}, 		{2, 23}, 		{3, 23}, 		{4, 23}, 		{5, 23}, 		{6, 23}, 		{7, 23},//6-1~6-8
	},	
	{
		{0, 24}, 		{1, 24}, 		{2, 24}, 		{3, 24}, 		{4, 24}, 		{5, 24}, 		{6, 24}, 		{7, 24},//7-1~7-8
	},	
	{
		{0, 25}, 		{1, 25}, 		{2, 25}, 		{3, 25}, 		{4, 25}, 		{5, 25}, 		{6, 25}, 		{7, 25},//8-1~8-8
	},		
	{
		{0, 26}, 		{1, 26}, 		{2, 26}, 		{3, 26}, 		{4, 26}, 		{5, 26}, 		{6, 26}, 		{7, 26},//9-1~9-8
	},	
	{
		{0, 27}, 		{1, 27}, 		{2, 27}, 		{3, 27}, 		{4, 27}, 		{5, 27}, 		{6, 27}, 		{7, 27},//10-1~10-8
	},		
	{
		{0, 35}, 		{1, 35}, 		{2, 35}, 		{3, 35}, 		{4, 35}, 		{5, 35}, 		{6, 35}, 		{7, 35},//11-1~11-8
	},		
	{
		{0, 36}, 		{1, 36}, 		{2, 36}, 		{3, 36}, 		{4, 36}, 		{5, 36}, 		{6, 36}, 		{7, 36},//12-1~12-8
	},	
	{
		{0, 37}, 		{1, 37}, 		{2, 37}, 		{3, 37}, 		{4, 37}, 		{5, 37}, 		{6, 37}, 		{7, 37},//13-1~13-8
	},		
	{
		{0, 38}, 		{1, 38}, 		{2, 38}, 		{3, 38}, 		{4, 38}, 		{5, 38}, 		{6, 38}, 		{7, 38},//14-1~14-8
	},	
	{
		{0, 39}, 		{1, 39}, 		{2, 39}, 		{3, 39}, 		{4, 39}, 		{5, 39}, 		{6, 39}, 		{7, 39},//15-1~15-8
	},	
};


static const LCD_ZONE_INFO_T g_LCDZoneInfo[] =
{
		{ZONE_SCORE_DIG_CNT,			ZONE_SCORE_SEG_NUM,			(unsigned short *)auScoreDigitMap,			(unsigned char *)acScoreDigitRawData},
		{ZONE_TIME_DIG_CNT,			ZONE_TIME_SEG_NUM,			(unsigned short *)auTimeDigitMap,			(unsigned char *)acTimeDigitRawData},
		{ZONE_MAIN_DOT_MATRIX_DIG_CNT,			ZONE_MAIN_DOT_MATRIX_SEG_NUM,			(unsigned short *)auNullDigitMap,			(unsigned char *)acMainDotDigitRawData},
};

/*@}*/ /* end of group LCDLIB_EXPORTED_STRUCTS */

/*@}*/ /* end of group LCDLIB */
    
/*@}*/ /* end of group Library */
    
#ifdef __cplusplus
}
#endif
    
#endif  /* __LCDZONE_H */