#ifndef __Tetris_H__
#define __Tetris_H__

#ifdef __cplusplus
extern "C"
{
#endif
#include <stdlib.h> 
#include "lcdlib.h"

typedef struct key
{
	int key_time;
	int Lcd_mode;
} key;


typedef enum BlockType
{
	BT_S = 0,
	BT_Z = 1,
	BT_J = 2,
	BT_L = 3,
	BT_I = 4,
	BT_T = 5,
	BT_O = 6,
	BT_NUM=7,
} BlockType;

// ????
typedef enum BlockState
{
	BS_T = 0,
	BS_R	,
	BS_B	,
	BS_L	,
	BS_NUM=4,
	
} BlockState;

typedef struct block
{
	uint8_t row;		// 
	uint8_t col;		// 
	BlockType type;		// 
	BlockState state;	//
} Block;

#define TETRIS_CONTAINER_WIDTH (1 + BLOCK_IMAGE_WIDTH + 1) //1+8+1=10
#define TETRIS_CONTAINER_HIGHT (BLOCK_HIGHT + BLOCK_IMAGE_HIGHT + 1) //4+15+1=20
#define TETRIS_BLOCK_NUM 2
#define BLOCK_WIDTH 4
#define BLOCK_HIGHT 4
#define	BLOCK_IMAGE_WIDTH 8
#define	BLOCK_IMAGE_HIGHT 15
//unsigned long blockContainer[TETRIS_CONTAINER_HIGHT];

typedef struct tetris
{
	unsigned long blockContainer[TETRIS_CONTAINER_HIGHT];		// 20
	int blockIndex;						// current block index
	Block blocks[TETRIS_BLOCK_NUM];		// next, current TETRIS_BLOCK_NUM=2 
	int tick;
	int speed;
	//......
} Tetris;
#define BLOCK_INIT_POSX 3 //(10-4)/2  
#define BLOCK_INIT_POSY 2

void block_test(Block block,uint8_t r,uint8_t c,unsigned long seed_time,uint8_t keymode);
void displayBlock(uint8_t r,uint8_t c, uint8_t a);
void initRandBlock(Block block, uint8_t r_2, uint8_t c_2,uint8_t keymode);
void init_Block_Container(uint8_t r_1,uint8_t c_1);
void renderBlock(Block block,unsigned char alpha);
int moveLeft(Block block);
int moveRight(Block block);
int moveDown(Block block);
int rotate(Block block);
int hitTest(const Block block, const Tetris tetris);
void merge(Block block, Tetris tetris);
int moveLeftBlock(Tetris tetris);
static void eraseLines(Tetris tetris);
int moveDownBlock(Tetris tetris, uint8_t x, uint8_t y ,uint8_t keymode ,uint8_t state);

#ifdef __cplusplus
}
#endif
#endif 