/***************************************************************************//**
 * @file     targetdev.h
 * @brief    ISP support function header file
 * @version  0x32
 * @date     14, June, 2017
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2017-2018 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __TARGET_H__
#define __TARGET_H__

#ifdef __cplusplus
extern "C"
{
#endif

// Nuvoton MCU Peripheral Access Layer Header File
#include "NuMicro.h"
#include "isp_user.h"
#define DetectPin                   PA0
#define ap_rom_size 128*1024
#define g_ckbase  (ap_rom_size - 8)

#ifdef __cplusplus
}
#endif

#endif //__TARGET_H__
